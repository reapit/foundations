import { DynamicModule, ForwardReference, InjectionToken, OptionalFactoryDependency, Type } from '@nestjs/common';
import { AccessTokenProviderConfigInterface } from './guards/access-token-provider';
export declare class AuthModule {
    static forRootAsync(options: {
        useFactory: (...args: any[]) => AccessTokenProviderConfigInterface | Promise<AccessTokenProviderConfigInterface>;
        inject?: Array<InjectionToken | OptionalFactoryDependency>;
        imports?: Array<Type<any> | DynamicModule | Promise<DynamicModule> | ForwardReference>;
    }): DynamicModule;
}
