"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isReadonlyAdmin = exports.isWriteAdmin = exports.isAdmin = void 0;
const consts_1 = require("../consts");
/**
 * Loose admin check. Checks if scopes present for readonly or write admin
 *
 * @param creds CredsType
 * @returns boolean
 */
const isAdmin = (creds) => creds.type === 'jwt' && creds.groups.some((group) => [consts_1.adminWriteGroup, consts_1.adminReadonlyGroup].includes(group));
exports.isAdmin = isAdmin;
/**
 * Returns true if creds have required scope for write access
 *
 * @param creds CredsType
 * @returns boolean
 */
const isWriteAdmin = (creds) => creds.type === 'jwt' && creds.groups.includes(consts_1.adminWriteGroup);
exports.isWriteAdmin = isWriteAdmin;
/**
 * Returns true if creds have required scopes for readonly admin
 *
 * @param creds CredsType
 * @returns boolean
 */
const isReadonlyAdmin = (creds) => (0, exports.isAdmin)(creds);
exports.isReadonlyAdmin = isReadonlyAdmin;
//# sourceMappingURL=admin-helpers.js.map