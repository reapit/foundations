import { AppBrowseLiveDataInterface, AppsBrowseConfigItemContentInterface, AppsBrowseConfigItemFiltersInterface, AppsBrowseConfigEnum, AppsBrowseConfigItemInterface } from '@reapit/foundations-ts-definitions';
declare class AppBrowseLiveDataModel implements AppBrowseLiveDataInterface {
    timeFrom?: string;
    timeTo?: string;
    isLive: boolean;
}
declare class AppBrowseConfigContentModel implements AppsBrowseConfigItemContentInterface {
    brandColour?: string;
    strapline?: string;
    imageUrl?: string;
    title?: string;
    iconName?: string;
}
declare class AppsBrowseConfigItemFiltersModel implements AppsBrowseConfigItemFiltersInterface {
    developerId?: string;
    category?: string[];
    desktopIntegrationTypeId?: string[];
    id?: string[];
    appName?: string;
    isFeatured?: boolean;
    isFree?: boolean;
}
export declare class MarketplaceAppModel implements AppsBrowseConfigItemInterface {
    id?: string;
    name?: string;
    live: AppBrowseLiveDataModel;
    configType: AppsBrowseConfigEnum;
    content?: AppBrowseConfigContentModel;
    filters: AppsBrowseConfigItemFiltersModel;
    index: number;
}
export {};
