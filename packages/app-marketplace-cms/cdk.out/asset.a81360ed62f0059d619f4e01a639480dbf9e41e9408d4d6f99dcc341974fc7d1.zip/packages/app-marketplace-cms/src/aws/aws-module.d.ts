export declare class AwsModule {
}
