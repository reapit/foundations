export declare class CmsModule {
}
