import { AppsBrowseConfigItemInterface, AppsBrowseConfigItemContentInterface, AppsBrowseConfigItemFiltersInterface, AppsBrowseConfigEnum, AppBrowseLiveDataInterface } from '@reapit/foundations-ts-definitions';
declare class AppBrowseConfigContentDto implements AppsBrowseConfigItemContentInterface {
    brandColour?: string;
    strapline?: string;
    imageUrl?: string;
    title?: string;
    iconName?: string;
}
declare class AppsBrowseConfigItemFiltersDto implements AppsBrowseConfigItemFiltersInterface {
    developerId?: string;
    category?: string[];
    desktopIntegrationTypeId?: string[];
    id?: string[];
    appName?: string;
    isFeatured?: boolean;
    isFree?: boolean;
}
declare class AppBrowseLiveDataDto implements AppBrowseLiveDataInterface {
    timeFrom?: Date;
    timeTo?: Date;
    isLive?: boolean;
}
export declare class MarketplaceAppModelDto implements AppsBrowseConfigItemInterface {
    filters?: AppsBrowseConfigItemFiltersDto;
    content?: AppBrowseConfigContentDto;
    configType: AppsBrowseConfigEnum;
    live: AppBrowseLiveDataDto;
}
export {};
