import { QueryIterator } from '@aws/dynamodb-data-mapper';
import { CmsProvider } from './cms-provider';
import { MarketplaceAppModelDto } from './marketplace-app-dto';
import { MarketplaceAppModel } from './marketplace-app-model';
type Pagination<T> = {
    items: T[];
    meta: {
        nextCursor: string;
    };
};
export declare class CmsController {
    private readonly cmsProvider;
    constructor(cmsProvider: CmsProvider);
    protected resolvePaginationObject(configItems: [QueryIterator<MarketplaceAppModel>, {
        nextCursor: string;
    }]): Promise<Pagination<MarketplaceAppModel>>;
    fetch(): Promise<Pagination<MarketplaceAppModel>>;
    create(dto: MarketplaceAppModelDto): Promise<MarketplaceAppModel>;
    update(id: string, dto: MarketplaceAppModelDto): Promise<MarketplaceAppModel>;
    updateBatch(dtos: MarketplaceAppModelDto[]): Promise<MarketplaceAppModel[]>;
    delete(id: string): Promise<any>;
}
export {};
