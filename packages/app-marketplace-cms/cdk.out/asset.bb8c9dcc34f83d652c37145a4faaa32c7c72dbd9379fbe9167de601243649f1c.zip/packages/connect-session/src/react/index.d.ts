import { ReapitConnectHook } from '../types';
import { ReapitConnectBrowserSession } from '../browser';
export declare const useReapitConnect: (reapitConnectBrowserSession: ReapitConnectBrowserSession) => ReapitConnectHook;
