"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useReapitConnect = void 0;
const react_1 = __importDefault(require("react"));
const useReapitConnect = (reapitConnectBrowserSession) => {
    const [connectSession, setConnectSession] = react_1.default.useState(null);
    react_1.default.useEffect(() => {
        const connectGetSession = async () => {
            const session = await reapitConnectBrowserSession.connectSession();
            if (session) {
                setConnectSession(session);
            }
        };
        connectGetSession().catch((error) => console.error(error));
    }, [reapitConnectBrowserSession]);
    const connectAuthorizeRedirect = react_1.default.useCallback(() => {
        reapitConnectBrowserSession.connectAuthorizeRedirect();
    }, []);
    const connectLoginRedirect = react_1.default.useCallback(() => {
        reapitConnectBrowserSession.connectLoginRedirect();
    }, []);
    const connectLogoutRedirect = react_1.default.useCallback(() => {
        reapitConnectBrowserSession.connectLogoutRedirect();
    }, []);
    const connectIsDesktop = reapitConnectBrowserSession.connectIsDesktop;
    const connectHasSession = reapitConnectBrowserSession.connectHasSession;
    const connectInternalRedirect = reapitConnectBrowserSession.connectInternalRedirect;
    const connectClearSession = reapitConnectBrowserSession.connectClearSession;
    return {
        connectSession,
        connectAuthorizeRedirect,
        connectLoginRedirect,
        connectLogoutRedirect,
        connectInternalRedirect,
        connectIsDesktop,
        connectHasSession,
        connectClearSession,
    };
};
exports.useReapitConnect = useReapitConnect;
//# sourceMappingURL=index.js.map