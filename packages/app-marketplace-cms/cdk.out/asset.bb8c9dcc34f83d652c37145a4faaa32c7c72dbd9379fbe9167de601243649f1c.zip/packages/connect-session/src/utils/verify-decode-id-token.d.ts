import 'isomorphic-fetch';
import { LoginIdentity } from '../types';
export type DecodedToken<T extends any> = {
    aud: string;
} & T;
export declare const connectSessionVerifyDecodeIdTokenWithPublicKeys: (token: string) => Promise<LoginIdentity | undefined>;
export declare const connectSessionVerifyDecodeIdToken: (token: string) => Promise<LoginIdentity | undefined>;
