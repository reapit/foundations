import { ReapitConnectServerSessionInitializers } from '../types';
export declare class ReapitConnectServerSession {
    static TOKEN_EXPIRY: number;
    private connectOAuthUrl;
    private connectClientId;
    private connectClientSecret;
    private accessToken;
    constructor({ connectClientId, connectClientSecret, connectOAuthUrl }: ReapitConnectServerSessionInitializers);
    private get accessTokenExpired();
    private connectGetAccessToken;
    connectAccessToken(): Promise<string | void>;
}
