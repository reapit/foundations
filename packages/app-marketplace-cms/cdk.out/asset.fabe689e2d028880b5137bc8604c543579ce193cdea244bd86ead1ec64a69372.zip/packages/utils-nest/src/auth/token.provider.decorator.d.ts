export declare const TOKEN_PROVIDER_INJECTABLE = "TOKEN_PROVIDER_INJECTABLE";
export declare const CredAuthTokenProvider: (priority: number) => (target: any) => void;
