import { CredsType } from '../guards';
/**
 * Loose admin check. Checks if scopes present for readonly or write admin
 *
 * @param creds CredsType
 * @returns boolean
 */
export declare const isAdmin: (creds: CredsType) => boolean;
/**
 * Returns true if creds have required scope for write access
 *
 * @param creds CredsType
 * @returns boolean
 */
export declare const isWriteAdmin: (creds: CredsType) => boolean;
/**
 * Returns true if creds have required scopes for readonly admin
 *
 * @param creds CredsType
 * @returns boolean
 */
export declare const isReadonlyAdmin: (creds: CredsType) => boolean;
