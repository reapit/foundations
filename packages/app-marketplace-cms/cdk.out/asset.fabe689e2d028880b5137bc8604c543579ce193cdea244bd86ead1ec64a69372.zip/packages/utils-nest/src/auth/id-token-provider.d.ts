import { LoginIdentity } from '@reapit/connect-session';
import { Request } from 'express';
import { AuthProviderInterface } from './auth-provider-interface';
export declare class IdTokenProvider implements AuthProviderInterface<any> {
    applies(): boolean;
    type(): string;
    resolve(request: Request): Promise<LoginIdentity>;
}
