import { CanActivate, ExecutionContext } from '@nestjs/common';
/**
 * Implement this guard after a cred guard (id-token guard or access-token guard)
 *
 * @UseGuard(IdTokenGuard, AdminWriteGuard)
 */
export declare class AdminWriteGuard implements CanActivate {
    canActivate(context: ExecutionContext): Promise<boolean>;
}
