"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdTokenGuard = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const constants_1 = require("@nestjs/common/constants");
const token_provider_decorator_1 = require("../token.provider.decorator");
const id_token_provider_1 = require("../id-token-provider");
let IdTokenGuard = class IdTokenGuard {
    constructor(moduleContainer, moduleRef) {
        this.moduleContainer = moduleContainer;
        this.moduleRef = moduleRef;
        this.authProviders = [];
        this.idTokenProvider = undefined;
    }
    onModuleInit() {
        const unsortedProviders = [];
        [...this.moduleContainer.values()].forEach(({ metatype }) => {
            const metadata = Reflect.getMetadata(constants_1.MODULE_METADATA.PROVIDERS, metatype);
            if (!metadata) {
                return;
            }
            const providers = [...metadata.filter((metatype) => typeof metatype === 'function')];
            providers.forEach((provider) => {
                if (Reflect.hasOwnMetadata(token_provider_decorator_1.TOKEN_PROVIDER_INJECTABLE, provider)) {
                    const injectable = this.moduleRef.get(provider, { strict: false });
                    if (injectable.constructor.name === id_token_provider_1.IdTokenProvider.name) {
                        this.idTokenProvider = injectable;
                    }
                    if (!unsortedProviders.find((unsortedProvider) => unsortedProvider.provider.constructor.name === injectable.constructor.name)) {
                        const priority = Reflect.getOwnMetadata(token_provider_decorator_1.TOKEN_PROVIDER_INJECTABLE, provider);
                        unsortedProviders.push({
                            priority,
                            provider: injectable,
                        });
                        // Logger.log(`added [${injectable.constructor.name}] to IdTokenGuard. Priority [${priority}]`,
                        // 'IdTokenGuard')
                    }
                }
            });
        });
        if (!this.idTokenProvider)
            throw new Error('[IdTokenProvider] was not found by IdTokenGuard. Please make sure IdTokenProvider is finable by IdTokenGuard. Likely IdTokenGuard provider is injected outside of AuthModule');
        unsortedProviders.sort((a, b) => b.priority - a.priority);
        this.authProviders = unsortedProviders.map((set) => set.provider);
    }
    async canActivate(context) {
        const request = context.switchToHttp().getRequest();
        const providers = this.authProviders.filter((provider) => provider.applies(request));
        const priorityProvider = providers[0] || this.idTokenProvider;
        // TODO should IdTokenProvider be instanced here instead of through container? To avoid exceptions in cases where
        // developer breaks usage and creates IdTokenGuard provider without AuthModule
        const credentials = await priorityProvider.resolve(request);
        if (credentials) {
            request.credentials = {
                ...credentials,
                type: priorityProvider.type(),
            };
        }
        return !!credentials;
    }
};
IdTokenGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.ModulesContainer, core_1.ModuleRef])
], IdTokenGuard);
exports.IdTokenGuard = IdTokenGuard;
//# sourceMappingURL=id-token-guard.js.map