export declare const adminReadonlyGroup = "ReapitEmployee";
export declare const adminWriteGroup = "ReapitEmployeeFoundationsAdmin";
export declare const ACCESS_TOKEN_PROVIDER_CONFIG_PROVIDE = "ACCESS_TOKEN_PROVIDER_CONFIG_PROVIDE";
