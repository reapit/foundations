"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppsBrowseConfigEnum = void 0;
var AppsBrowseConfigEnum;
(function (AppsBrowseConfigEnum) {
    AppsBrowseConfigEnum["FEATURED_HERO"] = "featuredHeroApps";
    AppsBrowseConfigEnum["HERO"] = "heroApps";
    AppsBrowseConfigEnum["FILTERS"] = "appsFilters";
    AppsBrowseConfigEnum["FEATURED"] = "featuredApps";
    AppsBrowseConfigEnum["SIMPLE"] = "simpleApps";
})(AppsBrowseConfigEnum = exports.AppsBrowseConfigEnum || (exports.AppsBrowseConfigEnum = {}));
//# sourceMappingURL=index.js.map