import { Request } from 'express';
import { CredsType } from './cred-types';
export declare class CredentialsRequestAppendProvider {
    appendCredsToRequest(request: Request & {
        credentials?: CredsType;
    }, credentials: any, type?: string): void;
}
