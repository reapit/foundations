"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccessTokenProvider = void 0;
const common_1 = require("@nestjs/common");
const consts_1 = require("../consts");
let AccessTokenProvider = class AccessTokenProvider {
    constructor(config) {
        this.config = config;
    }
    async fetchIdentity(accessToken) {
        const result = await fetch(this.config.env === 'dev'
            ? `https://platform.${this.config.env}.paas.reapit.cloud/userInfo`
            : 'https://platform.reapit.cloud/userInfo', {
            headers: {
                authorization: `Bearer ${accessToken}`,
                'api-version': 'latest',
            },
        });
        if (result.status !== 200)
            throw new common_1.UnauthorizedException();
        const userInfo = await result.json();
        return {
            ...userInfo,
            email: userInfo.userEmail,
            clientId: '', // not provided from userInfo?
            userCode: userInfo.customerId,
            orgId: userInfo.organisationId,
            groups: userInfo.userGroups,
            orgName: userInfo.organisationName,
            offGroupIds: '', // not provided from userInfo?
            agencyCloudId: userInfo.agencyCloudOfficeId,
        };
    }
};
exports.AccessTokenProvider = AccessTokenProvider;
exports.AccessTokenProvider = AccessTokenProvider = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(consts_1.ACCESS_TOKEN_PROVIDER_CONFIG_PROVIDE)),
    __metadata("design:paramtypes", [Object])
], AccessTokenProvider);
//# sourceMappingURL=access-token-provider.js.map