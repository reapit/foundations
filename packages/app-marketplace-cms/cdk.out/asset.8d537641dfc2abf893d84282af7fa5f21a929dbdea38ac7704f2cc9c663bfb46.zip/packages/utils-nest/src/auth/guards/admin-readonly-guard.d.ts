import { CanActivate, ExecutionContext } from '@nestjs/common';
/**
 * Implement this guard after a cred guard (id-token guard or access-token guard)
 *
 * @UseGuard(IdTokenGuard, AdminReadonlyGuard)
 */
export declare class AdminReadonlyGuard implements CanActivate {
    canActivate(context: ExecutionContext): Promise<boolean>;
}
