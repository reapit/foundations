"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicController = void 0;
const common_1 = require("@nestjs/common");
const marketplace_cms_1 = require("@reapit/foundations-ts-definitions/marketplace-cms");
const cms_provider_1 = require("./cms-provider");
let PublicController = class PublicController {
    constructor(cmsProvider) {
        this.cmsProvider = cmsProvider;
    }
    isLive(configItem, isLive = true) {
        const now = new Date().getTime();
        if (typeof configItem.live.timeFrom !== 'undefined' && typeof configItem.live.timeTo !== 'undefined') {
            const timeFromInRange = new Date(configItem.live.timeFrom).getTime() <= now;
            const timeToInRange = new Date(configItem.live.timeTo).getTime() >= now;
            if (timeFromInRange && timeToInRange) {
                return isLive;
            }
            return !isLive;
        }
        return typeof isLive === 'boolean'
            ? isLive
                ? configItem.live.isLive
                : !configItem.live.isLive
            : configItem.live.isLive;
    }
    async resolvePaginationObject(configItems, isLive, configType) {
        const pagination = {
            items: [],
            meta: configItems[1],
        };
        for await (const configItem of configItems[0]) {
            if (this.isLive(configItem, isLive)) {
                if (configType) {
                    if (configType === configItem.configType)
                        pagination.items.push(configItem);
                }
                else {
                    pagination.items.push(configItem);
                }
            }
        }
        return pagination;
    }
    async fetch(isLiveQuery, configType, configId) {
        const isLive = isLiveQuery === 'true' ? true : isLiveQuery === 'false' ? false : undefined;
        // return singular config for testing on frontend
        if (configId) {
            const config = await this.cmsProvider.findOne({ id: configId });
            return {
                items: config ? [config] : [],
                meta: {
                    nextCursor: '',
                },
            };
        }
        return this.resolvePaginationObject(await this.cmsProvider.findAll({}), isLive, configType);
    }
};
exports.PublicController = PublicController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('isLive')),
    __param(1, (0, common_1.Query)('configType')),
    __param(2, (0, common_1.Query)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], PublicController.prototype, "fetch", null);
exports.PublicController = PublicController = __decorate([
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [cms_provider_1.CmsProvider])
], PublicController);
//# sourceMappingURL=public-controller.js.map