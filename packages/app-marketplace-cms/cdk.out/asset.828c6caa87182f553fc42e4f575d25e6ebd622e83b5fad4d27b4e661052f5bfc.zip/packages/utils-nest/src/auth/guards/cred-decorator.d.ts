export declare const Creds: (...dataOrPipes: unknown[]) => ParameterDecorator;
