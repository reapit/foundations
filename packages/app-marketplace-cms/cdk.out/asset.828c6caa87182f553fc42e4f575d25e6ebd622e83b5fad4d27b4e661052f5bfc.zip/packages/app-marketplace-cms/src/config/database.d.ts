declare const _default: (() => {
    region: string | undefined;
}) & import("@nestjs/config").ConfigFactoryKeyHost<{
    region: string | undefined;
}>;
export default _default;
