import { QueryIterator } from '@aws/dynamodb-data-mapper';
import { AppsBrowseConfigEnum } from '@reapit/foundations-ts-definitions/marketplace-cms';
import { CmsProvider } from './cms-provider';
import { MarketplaceAppModel } from './marketplace-app-model';
type Pagination<T> = {
    items: T[];
    meta: {
        nextCursor: string;
    };
};
export declare class PublicController {
    private readonly cmsProvider;
    constructor(cmsProvider: CmsProvider);
    protected isLive(configItem: MarketplaceAppModel, isLive?: boolean | undefined): boolean;
    protected resolvePaginationObject(configItems: [QueryIterator<MarketplaceAppModel>, {
        nextCursor: string;
    }], isLive?: boolean, configType?: AppsBrowseConfigEnum): Promise<Pagination<MarketplaceAppModel>>;
    fetch(isLiveQuery: string, configType?: AppsBrowseConfigEnum, configId?: string): Promise<Pagination<MarketplaceAppModel>>;
}
export {};
