"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketplaceAppModelDto = void 0;
const foundations_ts_definitions_1 = require("@reapit/foundations-ts-definitions");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class AppBrowseConfigContentDto {
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AppBrowseConfigContentDto.prototype, "brandColour", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AppBrowseConfigContentDto.prototype, "strapline", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AppBrowseConfigContentDto.prototype, "imageUrl", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AppBrowseConfigContentDto.prototype, "title", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AppBrowseConfigContentDto.prototype, "iconName", void 0);
class AppsBrowseConfigItemFiltersDto {
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AppsBrowseConfigItemFiltersDto.prototype, "developerId", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], AppsBrowseConfigItemFiltersDto.prototype, "category", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], AppsBrowseConfigItemFiltersDto.prototype, "desktopIntegrationTypeId", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], AppsBrowseConfigItemFiltersDto.prototype, "id", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AppsBrowseConfigItemFiltersDto.prototype, "appName", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], AppsBrowseConfigItemFiltersDto.prototype, "isFeatured", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], AppsBrowseConfigItemFiltersDto.prototype, "isFree", void 0);
class AppBrowseLiveDataDto {
}
__decorate([
    (0, class_validator_1.IsDate)(),
    (0, class_transformer_1.Transform)((value) => new Date(value.value)),
    __metadata("design:type", Date)
], AppBrowseLiveDataDto.prototype, "timeFrom", void 0);
__decorate([
    (0, class_validator_1.IsDate)(),
    (0, class_transformer_1.Transform)((value) => new Date(value.value)),
    __metadata("design:type", Date)
], AppBrowseLiveDataDto.prototype, "timeTo", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], AppBrowseLiveDataDto.prototype, "isLive", void 0);
class MarketplaceAppModelDto {
}
exports.MarketplaceAppModelDto = MarketplaceAppModelDto;
__decorate([
    (0, class_transformer_1.Type)(() => AppsBrowseConfigItemFiltersDto),
    __metadata("design:type", AppsBrowseConfigItemFiltersDto)
], MarketplaceAppModelDto.prototype, "filters", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => AppBrowseConfigContentDto),
    __metadata("design:type", AppBrowseConfigContentDto)
], MarketplaceAppModelDto.prototype, "content", void 0);
__decorate([
    (0, class_validator_1.IsEnum)(foundations_ts_definitions_1.AppsBrowseConfigEnum),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], MarketplaceAppModelDto.prototype, "configType", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => AppBrowseLiveDataDto),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", AppBrowseLiveDataDto)
], MarketplaceAppModelDto.prototype, "live", void 0);
//# sourceMappingURL=marketplace-app-dto.js.map