"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = require("./http");
const bootstrap = async () => {
    const [app] = await (0, http_1.bootstrapApplication)();
    await app.init();
    app.listen(3000);
};
bootstrap().catch((error) => console.error(error));
//# sourceMappingURL=local-http.js.map