"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectSessionVerifyDecodeIdToken = exports.connectSessionVerifyDecodeIdTokenWithPublicKeys = void 0;
/* istanbul ignore file */
// Not possible to test this file without stubbing public keys. Obviously can't include these in the
// project for security reasons and using random strings would be basically worthless as a test.
// Given code comes from AWS, seems reasonable to trust the implementation.
require("isomorphic-fetch");
// We wanted to use idtoken-verifier, currently using bashleigh-idtoken-verifier
// as the types are incorrect in root package
const idtoken_verifier_1 = __importDefault(require("idtoken-verifier"));
const jwt_decode_1 = __importDefault(require("jwt-decode"));
const connectSessionVerifyDecodeIdTokenWithPublicKeys = async (token) => {
    try {
        const decodedToken = (0, jwt_decode_1.default)(token);
        const aud = decodedToken.aud;
        const verifier = new idtoken_verifier_1.default({
            issuer: decodedToken.iss,
            audience: Array.isArray(aud) ? aud[0] : aud,
            leeway: 300,
        });
        const claim = (await new Promise((resolve, reject) => verifier.verify(token, (err, payload) => {
            if (err) {
                reject(err);
            }
            resolve(payload);
        })));
        const currentSeconds = Math.floor(new Date().valueOf() / 1000);
        // Allow 5 minutes to avoid CPU clock latency issues. See: https://github.com/reapit/foundations/issues/2467
        // basically some Windows laptops calculate time not terribly accurately and can be out by as much as 2 or 3 mins
        // based on testing so the currentSeconds are before the auth_time in AWS.
        // Not ideal but prevents constant invalid id_token messages
        if (currentSeconds > claim.exp + 300 || currentSeconds + 300 < claim.auth_time)
            throw new Error('Id verification claim expired');
        if (claim.token_use !== 'id')
            throw new Error('Id verification claim is not an id token');
        return {
            name: claim['name'],
            email: claim['email'],
            agencyCloudId: claim['custom:reapit:agencyCloudId'] || null,
            developerId: claim['custom:reapit:developerId'] || null,
            clientId: claim['custom:reapit:clientCode'] || null,
            adminId: claim['custom:reapit:marketAdmin'] || null,
            userCode: claim['custom:reapit:userCode'] || null,
            groups: claim['cognito:groups'] || [],
            orgName: claim['custom:reapit:orgName'] || null,
            orgId: claim['custom:reapit:orgId'] || null,
            offGroupIds: claim['custom:reapit:offGroupIds'] || null,
            offGrouping: claim['custom:reapit:offGrouping'] && claim['custom:reapit:offGrouping'] === 'true' ? true : false,
            offGroupName: claim['custom:reapit:offGroupName'] || null,
            officeId: claim['custom:reapit:officeId'] || null,
            orgProduct: claim['custom:reapit:orgProduct'] || null,
        };
    }
    catch (error) {
        console.error('Reapit Connect Session error:', error.message);
    }
};
exports.connectSessionVerifyDecodeIdTokenWithPublicKeys = connectSessionVerifyDecodeIdTokenWithPublicKeys;
const connectSessionVerifyDecodeIdToken = async (token) => {
    return (0, exports.connectSessionVerifyDecodeIdTokenWithPublicKeys)(token);
};
exports.connectSessionVerifyDecodeIdToken = connectSessionVerifyDecodeIdToken;
//# sourceMappingURL=verify-decode-id-token.js.map