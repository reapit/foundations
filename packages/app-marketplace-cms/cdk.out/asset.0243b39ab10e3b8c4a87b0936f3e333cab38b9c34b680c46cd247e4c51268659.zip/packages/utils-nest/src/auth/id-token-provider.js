"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdTokenProvider = void 0;
const common_1 = require("@nestjs/common");
const connect_session_1 = require("@reapit/connect-session");
const token_provider_decorator_1 = require("./token.provider.decorator");
let IdTokenProvider = class IdTokenProvider {
    applies() {
        return true;
    }
    type() {
        return 'jwt';
    }
    async resolve(request) {
        var _a;
        try {
            const authorization = (_a = request.headers) === null || _a === void 0 ? void 0 : _a.authorization;
            if (!authorization)
                throw new common_1.UnauthorizedException('Authorization header not found');
            const claim = await (0, connect_session_1.connectSessionVerifyDecodeIdTokenWithPublicKeys)(authorization.replace('Bearer ', ''));
            if (!claim) {
                throw new Error('unauthorised');
            }
            return claim;
        }
        catch (e) {
            throw new common_1.UnauthorizedException(String(e));
        }
    }
};
exports.IdTokenProvider = IdTokenProvider;
exports.IdTokenProvider = IdTokenProvider = __decorate([
    (0, token_provider_decorator_1.CredAuthTokenProvider)(1)
], IdTokenProvider);
//# sourceMappingURL=id-token-provider.js.map