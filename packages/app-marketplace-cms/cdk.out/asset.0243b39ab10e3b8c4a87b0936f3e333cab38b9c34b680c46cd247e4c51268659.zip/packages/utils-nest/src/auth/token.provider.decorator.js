"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CredAuthTokenProvider = exports.TOKEN_PROVIDER_INJECTABLE = void 0;
exports.TOKEN_PROVIDER_INJECTABLE = 'TOKEN_PROVIDER_INJECTABLE';
const CredAuthTokenProvider = (priority) => (target) => {
    Reflect.defineMetadata(exports.TOKEN_PROVIDER_INJECTABLE, priority, target);
};
exports.CredAuthTokenProvider = CredAuthTokenProvider;
//# sourceMappingURL=token.provider.decorator.js.map