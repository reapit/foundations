export declare class OwnershipProvider {
    check<T extends {
        developerId?: string;
    }>(entity: T, developerId: string): void | never;
}
