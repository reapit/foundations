import { LoginIdentity } from '@reapit/connect-session';
export interface AccessTokenProviderConfigInterface {
    env: 'dev' | 'prod';
}
export declare class AccessTokenProvider {
    private readonly config;
    constructor(config: AccessTokenProviderConfigInterface);
    fetchIdentity(accessToken: string): Promise<Partial<LoginIdentity>>;
}
