import { CanActivate, ExecutionContext } from '@nestjs/common';
import { AccessTokenProvider } from './access-token-provider';
import { CredentialsRequestAppendProvider } from './credentials-request-append-provider';
export declare class AccessTokenGuard implements CanActivate {
    private readonly accessTokenProvider;
    private readonly credentialsRequestAppendPrvovider;
    constructor(accessTokenProvider: AccessTokenProvider, credentialsRequestAppendPrvovider: CredentialsRequestAppendProvider);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
