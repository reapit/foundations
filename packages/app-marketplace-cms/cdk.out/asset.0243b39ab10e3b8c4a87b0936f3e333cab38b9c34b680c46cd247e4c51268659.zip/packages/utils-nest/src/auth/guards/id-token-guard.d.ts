import { CanActivate, ExecutionContext } from '@nestjs/common';
import { AuthProviderInterface } from '../auth-provider-interface';
import { ModuleRef, ModulesContainer } from '@nestjs/core';
import { IdTokenProvider } from '../id-token-provider';
export declare class IdTokenGuard implements CanActivate {
    private readonly moduleContainer;
    private readonly moduleRef;
    protected authProviders: AuthProviderInterface<any>[];
    protected idTokenProvider: IdTokenProvider | undefined;
    constructor(moduleContainer: ModulesContainer, moduleRef: ModuleRef);
    onModuleInit(): void;
    canActivate(context: ExecutionContext): Promise<boolean>;
}
