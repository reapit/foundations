"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CmsProvider = void 0;
const dynamodb_data_mapper_1 = require("@aws/dynamodb-data-mapper");
const common_1 = require("@nestjs/common");
const class_transformer_1 = require("class-transformer");
const marketplace_app_model_1 = require("./marketplace-app-model");
let CmsProvider = class CmsProvider {
    constructor(dataMapper) {
        this.dataMapper = dataMapper;
    }
    async findAll(props) {
        const { startKey, indexName } = props;
        const dynamoResponse = await this.dataMapper.scan(marketplace_app_model_1.MarketplaceAppModel, {
            indexName,
            limit: 100,
            startKey,
        });
        return [
            dynamoResponse,
            {
                nextCursor: '',
            },
        ];
    }
    async findOne(model) {
        try {
            return this.dataMapper.get(Object.assign(new marketplace_app_model_1.MarketplaceAppModel(), model));
        }
        catch (e) {
            console.log(e, typeof e, e instanceof dynamodb_data_mapper_1.ItemNotFoundException, e.constructor, e.constructor.prototype);
            if (e instanceof dynamodb_data_mapper_1.ItemNotFoundException) {
                return undefined;
            }
            throw e;
        }
    }
    async create(dto) {
        return this.dataMapper.put(Object.assign(new marketplace_app_model_1.MarketplaceAppModel(), { ...dto }));
    }
    async update(marketplaceApp, dto) {
        return this.dataMapper.put((0, class_transformer_1.plainToInstance)(marketplace_app_model_1.MarketplaceAppModel, {
            ...marketplaceApp,
            ...dto,
        }));
    }
    async updateBatch(dtos) {
        const result = [];
        for await (const persisted of this.dataMapper.batchPut((0, class_transformer_1.plainToInstance)(marketplace_app_model_1.MarketplaceAppModel, dtos))) {
            result.push(persisted);
        }
        return result;
    }
    async delete(marketplaceApp) {
        return this.dataMapper.delete(marketplaceApp);
    }
};
exports.CmsProvider = CmsProvider;
exports.CmsProvider = CmsProvider = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [dynamodb_data_mapper_1.DataMapper])
], CmsProvider);
//# sourceMappingURL=cms-provider.js.map