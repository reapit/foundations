import { DataMapper, QueryIterator } from '@aws/dynamodb-data-mapper';
import { MarketplaceAppModelDto } from './marketplace-app-dto';
import { MarketplaceAppModel } from './marketplace-app-model';
export declare class CmsProvider {
    private readonly dataMapper;
    constructor(dataMapper: DataMapper);
    findAll(props: {
        indexName?: string;
        startKey?: Partial<MarketplaceAppModel>;
    }): Promise<[QueryIterator<MarketplaceAppModel>, {
        nextCursor: string;
    }]>;
    findOne(model: Partial<MarketplaceAppModel>): Promise<MarketplaceAppModel | undefined>;
    create(dto: MarketplaceAppModelDto): Promise<MarketplaceAppModel>;
    update(marketplaceApp: MarketplaceAppModel, dto: MarketplaceAppModelDto): Promise<MarketplaceAppModel>;
    updateBatch(dtos: MarketplaceAppModelDto[]): Promise<MarketplaceAppModel[]>;
    delete(marketplaceApp: MarketplaceAppModel): Promise<MarketplaceAppModel | undefined>;
}
