import { INestApplication } from '@nestjs/common';
import { Handler } from 'aws-lambda';
import { Express } from 'express';
export declare const bootstrapApplication: () => Promise<[INestApplication, Express]>;
export declare const handler: Handler;
