"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiKeyEntityType = void 0;
var ApiKeyEntityType;
(function (ApiKeyEntityType) {
    ApiKeyEntityType["PAYMENT"] = "payment";
    ApiKeyEntityType["DEPLOYMENT"] = "deployment";
})(ApiKeyEntityType = exports.ApiKeyEntityType || (exports.ApiKeyEntityType = {}));
//# sourceMappingURL=index.js.map