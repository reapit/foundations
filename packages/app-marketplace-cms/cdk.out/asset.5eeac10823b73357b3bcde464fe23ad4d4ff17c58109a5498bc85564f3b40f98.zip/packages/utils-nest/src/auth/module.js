"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var AuthModule_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthModule = void 0;
const common_1 = require("@nestjs/common");
const guards_1 = require("./guards");
const ownership_provider_1 = require("./ownership-provider");
const id_token_provider_1 = require("./id-token-provider");
const access_token_guard_1 = require("./guards/access-token-guard");
const access_token_provider_1 = require("./guards/access-token-provider");
const consts_1 = require("./consts");
const credentials_request_append_provider_1 = require("./guards/credentials-request-append-provider");
let AuthModule = AuthModule_1 = class AuthModule {
    static forRootAsync(options) {
        return {
            module: AuthModule_1,
            imports: [...(options.imports || [])],
            providers: [
                {
                    provide: consts_1.ACCESS_TOKEN_PROVIDER_CONFIG_PROVIDE,
                    useFactory: options.useFactory,
                    inject: options.inject,
                },
                ownership_provider_1.OwnershipProvider,
                guards_1.IdTokenGuard,
                id_token_provider_1.IdTokenProvider,
                guards_1.AdminWriteGuard,
                guards_1.AdminReadonlyGuard,
                access_token_guard_1.AccessTokenGuard,
                access_token_provider_1.AccessTokenProvider,
                credentials_request_append_provider_1.CredentialsRequestAppendProvider,
            ],
            exports: [
                consts_1.ACCESS_TOKEN_PROVIDER_CONFIG_PROVIDE,
                ownership_provider_1.OwnershipProvider,
                guards_1.IdTokenGuard,
                id_token_provider_1.IdTokenProvider,
                guards_1.AdminWriteGuard,
                guards_1.AdminReadonlyGuard,
                access_token_guard_1.AccessTokenGuard,
                access_token_provider_1.AccessTokenProvider,
                credentials_request_append_provider_1.CredentialsRequestAppendProvider,
            ],
        };
    }
};
AuthModule = AuthModule_1 = __decorate([
    (0, common_1.Module)({
        providers: [
            ownership_provider_1.OwnershipProvider,
            id_token_provider_1.IdTokenProvider,
            guards_1.IdTokenGuard,
            guards_1.AdminWriteGuard,
            guards_1.AdminReadonlyGuard,
            access_token_guard_1.AccessTokenGuard,
            access_token_provider_1.AccessTokenProvider,
            credentials_request_append_provider_1.CredentialsRequestAppendProvider,
        ],
        exports: [
            ownership_provider_1.OwnershipProvider,
            guards_1.IdTokenGuard,
            id_token_provider_1.IdTokenProvider,
            guards_1.AdminWriteGuard,
            guards_1.AdminReadonlyGuard,
            access_token_guard_1.AccessTokenGuard,
            access_token_provider_1.AccessTokenProvider,
            credentials_request_append_provider_1.CredentialsRequestAppendProvider,
        ],
    }),
    (0, common_1.Global)()
], AuthModule);
exports.AuthModule = AuthModule;
//# sourceMappingURL=module.js.map