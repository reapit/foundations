"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ACCESS_TOKEN_PROVIDER_CONFIG_PROVIDE = exports.adminWriteGroup = exports.adminReadonlyGroup = void 0;
exports.adminReadonlyGroup = 'ReapitEmployee';
exports.adminWriteGroup = 'ReapitEmployeeFoundationsAdmin';
exports.ACCESS_TOKEN_PROVIDER_CONFIG_PROVIDE = 'ACCESS_TOKEN_PROVIDER_CONFIG_PROVIDE';
//# sourceMappingURL=consts.js.map