"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isBase64 = void 0;
const base64Regex = new RegExp('^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})$');
const isBase64 = (base64Str) => {
    try {
        const base64Value = (base64Str && base64Str.split(';base64,')[1]) || '';
        return base64Regex.test(base64Value);
    }
    catch (error) {
        return false;
    }
};
exports.isBase64 = isBase64;
//# sourceMappingURL=index.js.map