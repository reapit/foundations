"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateOffice = exports.createOffice = exports.getOffices = exports.getOfficeById = void 0;
const api_1 = require("./api");
const getOfficeById = (args, context) => {
    const office = (0, api_1.callGetOfficeByIdAPI)(args, context);
    return office;
};
exports.getOfficeById = getOfficeById;
const getOffices = (args, context) => {
    const offices = (0, api_1.callGetOfficesAPI)(args, context);
    return offices;
};
exports.getOffices = getOffices;
const createOffice = (args, context) => {
    const createResult = (0, api_1.callCreateOfficeAPI)(args, context);
    return createResult;
};
exports.createOffice = createOffice;
const updateOffice = (args, context) => {
    const updateResult = (0, api_1.callUpdateOfficeAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateOffice = updateOffice;
const officeServices = {
    getOfficeById: exports.getOfficeById,
    getOffices: exports.getOffices,
    createOffice: exports.createOffice,
    updateOffice: exports.updateOffice,
};
exports.default = officeServices;
//# sourceMappingURL=services.js.map