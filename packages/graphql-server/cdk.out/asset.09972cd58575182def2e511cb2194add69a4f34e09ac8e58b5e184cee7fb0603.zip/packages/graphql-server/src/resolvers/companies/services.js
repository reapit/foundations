"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateCompany = exports.createCompany = exports.getCompanyRoles = exports.getCompanies = exports.getCompanyById = void 0;
const api_1 = require("./api");
const getCompanyById = (args, context) => {
    const property = (0, api_1.callGetCompanyByIdAPI)(args, context);
    return property;
};
exports.getCompanyById = getCompanyById;
const getCompanies = (args, context) => {
    const companies = (0, api_1.callGetCompaniesAPI)(args, context);
    return companies;
};
exports.getCompanies = getCompanies;
const getCompanyRoles = (args, context) => {
    const companyRoles = (0, api_1.callGetCompanyRolesAPI)(args, context);
    return companyRoles;
};
exports.getCompanyRoles = getCompanyRoles;
const createCompany = (args, context) => {
    const createResult = (0, api_1.callCreateCompanyAPI)(args, context);
    return createResult;
};
exports.createCompany = createCompany;
const updateCompany = (args, context) => {
    const updateResult = (0, api_1.callUpdateCompanyAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateCompany = updateCompany;
const propertyServices = {
    getCompanyById: exports.getCompanyById,
    getCompanies: exports.getCompanies,
    getCompanyRoles: exports.getCompanyRoles,
    createCompany: exports.createCompany,
    updateCompany: exports.updateCompany,
};
exports.default = propertyServices;
//# sourceMappingURL=services.js.map