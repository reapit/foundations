"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationCreateWorksOrder = exports.queryGetWorksOrdersById = exports.queryGetWorksOrder = exports.mutationUpdateWorksOrder = exports.queryGetWorksOrderItems = exports.queryGetWorksOrderById = exports.mutationCreateWorksOrderItem = exports.mutationUpdateWorksOrderItem = exports.mutationdeleteWorksOrderItem = void 0;
const utils_1 = require("../../utils");
const worksOrdersServices = __importStar(require("./services"));
exports.mutationdeleteWorksOrderItem = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.deleteWorksOrderItem(args, context);
});
exports.mutationUpdateWorksOrderItem = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.updateWorksOrderItem(args, context);
});
exports.mutationCreateWorksOrderItem = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.createWorksOrderItem(args, context);
});
exports.queryGetWorksOrderById = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.getWorksOrderItemById(args, context);
});
exports.queryGetWorksOrderItems = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.getWorksOrderItems(args, context);
});
exports.mutationUpdateWorksOrder = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.updateWorksOrder(args, context);
});
exports.queryGetWorksOrder = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.getWorksOrders(args, context);
});
exports.queryGetWorksOrdersById = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.getWorkOrderById(args, context);
});
exports.mutationCreateWorksOrder = (0, utils_1.resolverHandler)((_, args, context) => {
    return worksOrdersServices.createWorksOrder(args, context);
});
exports.default = {
    Query: {
        GetWorksOrders: exports.queryGetWorksOrder,
        GetWorksOrdersById: exports.queryGetWorksOrdersById,
        GetWorksOrderItems: exports.queryGetWorksOrderItems,
        GetWorksOrderItemById: exports.queryGetWorksOrderById,
    },
    Mutation: {
        CreateWorksOrder: exports.mutationCreateWorksOrder,
        UpdateWorksOrder: exports.mutationUpdateWorksOrder,
        CreateWorksOrderItem: exports.mutationCreateWorksOrderItem,
        UpdateWorksOrderItem: exports.mutationUpdateWorksOrderItem,
        DeleteWorksOrderItem: exports.mutationdeleteWorksOrderItem,
    },
};
//# sourceMappingURL=resolvers.js.map