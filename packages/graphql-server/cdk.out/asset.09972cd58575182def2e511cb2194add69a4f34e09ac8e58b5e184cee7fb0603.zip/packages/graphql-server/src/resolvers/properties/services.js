"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateProperty = exports.createProperty = exports.getProperties = exports.getPropertyById = void 0;
const api_1 = require("./api");
const getPropertyById = (args, context) => {
    const property = (0, api_1.callGetPropertyByIdAPI)(args, context);
    return property;
};
exports.getPropertyById = getPropertyById;
const getProperties = (args, context) => {
    const properties = (0, api_1.callGetPropertiesAPI)(args, context);
    return properties;
};
exports.getProperties = getProperties;
const createProperty = (args, context) => {
    const createResult = (0, api_1.callCreatePropertyAPI)(args, context);
    return createResult;
};
exports.createProperty = createProperty;
const updateProperty = (args, context) => {
    const updateResult = (0, api_1.callUpdatePropertyAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateProperty = updateProperty;
const propertyServices = {
    getPropertyById: exports.getPropertyById,
    getProperties: exports.getProperties,
    createProperty: exports.createProperty,
    updateProperty: exports.updateProperty,
};
exports.default = propertyServices;
//# sourceMappingURL=services.js.map