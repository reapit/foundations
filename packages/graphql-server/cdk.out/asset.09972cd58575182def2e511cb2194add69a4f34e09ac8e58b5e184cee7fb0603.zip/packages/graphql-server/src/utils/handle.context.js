"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleContext = exports.headersToContext = void 0;
const dataloader_1 = require("./../resolvers/configurations/dataloader");
const dataloader_2 = require("./../resolvers/properties/dataloader");
const dataloader_3 = require("./../resolvers/offices/dataloader");
const dataloader_4 = require("./../resolvers/negotiators/dataloader");
const uuid_1 = require("uuid");
const dataloader_5 = require("../resolvers/contacts/dataloader");
const headersToContext = (headers, extras) => {
    var _a, _b;
    const reapitCustomer = (_a = headers['reapit-customer']) !== null && _a !== void 0 ? _a : 'UNKNOWN-CUSTOMER';
    const traceId = `${reapitCustomer}-${(0, uuid_1.v4)()}`;
    const newContext = Object.assign({ traceId: traceId, headers: headers, authorization: (_b = headers['reapit-connect-token']) !== null && _b !== void 0 ? _b : '' }, extras);
    const dataLoader = {
        configurationLoader: (0, dataloader_1.generateConfigurationLoader)(newContext),
        propertyLoader: (0, dataloader_2.generatePropertyLoader)(newContext),
        officeLoader: (0, dataloader_3.generateOfficeLoader)(newContext),
        negotiatorLoader: (0, dataloader_4.generateNegotiatorLoader)(newContext),
        contactLoader: (0, dataloader_5.generateContactLoader)(newContext),
    };
    newContext.dataLoader = dataLoader;
    return newContext;
};
exports.headersToContext = headersToContext;
const handleContext = ({ event, context }) => {
    const extras = {
        functionName: context.functionName,
        event,
        context,
    };
    return (0, exports.headersToContext)(event.headers, extras);
};
exports.handleContext = handleContext;
//# sourceMappingURL=handle.context.js.map