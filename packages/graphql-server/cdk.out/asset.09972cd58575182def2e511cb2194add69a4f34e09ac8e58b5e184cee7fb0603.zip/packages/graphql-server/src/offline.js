"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const apollo_server_1 = require("apollo-server");
const graphql_common_1 = require("./graphql-common");
const utils_1 = require("./utils");
const server = new apollo_server_1.ApolloServer(Object.assign(Object.assign({}, graphql_common_1.config), { plugins: undefined, context: ({ req }) => {
        return (0, utils_1.headersToContext)(req.headers, {});
    } }));
server.listen(4001).then(({ url }) => {
    console.log(`🚀  Server ready at ${url}`);
});
//# sourceMappingURL=offline.js.map