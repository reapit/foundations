"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createLogger = exports.levels = exports.traceIdMiddleware = exports.createParseLog = void 0;
const winston_1 = __importDefault(require("winston"));
const uuid_1 = require("uuid");
const sentry_logger_1 = require("./sentry-logger");
/**
 * create fn
 * forward log to wiston
 */
const createParseLog = (logger) => (tokens, req, res) => {
    const log = {
        traceId: req.traceId,
        method: tokens.method(req, res),
        endpoint: tokens.url(req, res),
        status: tokens.status(req, res),
        contentLength: String(tokens.res(req, res, 'content-length')),
        responseTime: tokens['response-time'](req, res),
        reqHeader: JSON.stringify(req.headers),
        reqBody: JSON.stringify(req.body),
    };
    logger.info(log);
    return [
        tokens.method(req, res),
        tokens.url(req, res),
        tokens.status(req, res),
        tokens.res(req, res, 'content-length'),
        '-',
        tokens['response-time'](req, res),
        'ms',
    ].join(' ');
};
exports.createParseLog = createParseLog;
const traceIdMiddleware = (req, res, next) => {
    const traceId = (0, uuid_1.v4)();
    req.traceId = traceId;
    next();
};
exports.traceIdMiddleware = traceIdMiddleware;
exports.levels = {
    error: 0,
    warn: 1,
    info: 2,
    http: 3,
    verbose: 4,
    debug: 5,
    silly: 6,
};
const createLogger = (service) => {
    const logger = winston_1.default.createLogger({
        format: winston_1.default.format.combine(winston_1.default.format.json()),
        defaultMeta: { service },
        exitOnError: false,
        transports: [
            new winston_1.default.transports.Console({
                format: winston_1.default.format.combine(winston_1.default.format.json()),
            }),
        ],
    });
    logger.error = (0, sentry_logger_1.createWistonLoggerErrorFn)(logger.error);
    return logger;
};
exports.createLogger = createLogger;
//# sourceMappingURL=logger.js.map