"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWorkOrderById = exports.getWorksOrders = exports.createWorksOrder = exports.updateWorksOrder = exports.getWorksOrderItems = exports.getWorksOrderItemById = exports.createWorksOrderItem = exports.deleteWorksOrderItem = exports.updateWorksOrderItem = void 0;
const api_1 = require("./api");
const updateWorksOrderItem = (args, context) => {
    const worksOrder = (0, api_1.callUpdateWorksOrderItemAPI)(args, context);
    return worksOrder;
};
exports.updateWorksOrderItem = updateWorksOrderItem;
const deleteWorksOrderItem = (args, context) => {
    return (0, api_1.calldeleteWorksOrderItem)(args, context);
};
exports.deleteWorksOrderItem = deleteWorksOrderItem;
const createWorksOrderItem = (args, context) => {
    const worksOrder = (0, api_1.callCreateWorksOrderItemAPI)(args, context);
    return worksOrder;
};
exports.createWorksOrderItem = createWorksOrderItem;
const getWorksOrderItemById = (args, context) => {
    const worksOrder = (0, api_1.callGetWorksOrderItemByIdAPI)(args, context);
    return worksOrder;
};
exports.getWorksOrderItemById = getWorksOrderItemById;
const getWorksOrderItems = (args, context) => {
    const worksOrderItems = (0, api_1.callGetWorksOrderItemsAPI)(args, context);
    return worksOrderItems;
};
exports.getWorksOrderItems = getWorksOrderItems;
const updateWorksOrder = (args, context) => {
    const worksOrder = (0, api_1.callUpdateWorksOrderAPI)(args, context);
    return worksOrder;
};
exports.updateWorksOrder = updateWorksOrder;
const createWorksOrder = (args, context) => {
    const worksOrder = (0, api_1.callCreateWorksOrderdAPI)(args, context);
    return worksOrder;
};
exports.createWorksOrder = createWorksOrder;
const getWorksOrders = (args, context) => {
    const worksOrders = (0, api_1.callGetWorksOrdersAPI)(args, context);
    return worksOrders;
};
exports.getWorksOrders = getWorksOrders;
const getWorkOrderById = (args, context) => {
    const worksOrder = (0, api_1.callGetWorksOrderByIdAPI)(args, context);
    return worksOrder;
};
exports.getWorkOrderById = getWorkOrderById;
//# sourceMappingURL=services.js.map