"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryOffices = exports.queryNegotiators = exports.queryProperty = exports.queryConfiguration = exports.mutationUpdateAppointment = exports.mutationCreateAppointment = exports.queryGetAppointments = exports.queryGetAppointmentById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetAppointmentById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getAppointmentById(args, context);
});
exports.queryGetAppointments = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getAppointments(args, context);
});
exports.mutationCreateAppointment = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createAppointment(args, context);
});
exports.mutationUpdateAppointment = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateAppointment(args, context);
});
const queryConfiguration = (appointment, _, context) => {
    return context.dataLoader.configurationLoader.load(appointment.typeId);
};
exports.queryConfiguration = queryConfiguration;
const queryProperty = (appointment, _, context) => {
    return context.dataLoader.propertyLoader.load(appointment.propertyId);
};
exports.queryProperty = queryProperty;
const queryNegotiators = (appointment, _, context) => {
    return context.dataLoader.negotiatorLoader.loadMany(appointment.negotiatorIds);
};
exports.queryNegotiators = queryNegotiators;
const queryOffices = (appointment, _, context) => {
    return context.dataLoader.officeLoader.loadMany(appointment.officeIds);
};
exports.queryOffices = queryOffices;
exports.default = {
    Query: {
        GetAppointmentById: exports.queryGetAppointmentById,
        GetAppointments: exports.queryGetAppointments,
    },
    Mutation: {
        CreateAppointment: exports.mutationCreateAppointment,
        UpdateAppointment: exports.mutationUpdateAppointment,
    },
    AppointmentModel: {
        property: exports.queryProperty,
        appointmentType: exports.queryConfiguration,
        offices: exports.queryOffices,
        negotiators: exports.queryNegotiators,
    },
};
//# sourceMappingURL=resolvers.js.map