"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callUpdateSourceAPI = exports.callCreateSourceAPI = exports.callGetSourcesAPI = exports.callGetSourceByIdAPI = void 0;
const query_string_1 = __importDefault(require("query-string"));
const logger_1 = __importDefault(require("../../logger"));
const errors_1 = __importDefault(require("../../errors"));
const api_1 = require("../../constants/api");
const axios_instances_1 = require("../../utils/axios-instances");
const handle_error_1 = require("../../utils/handle-error");
const get_id_from_create_headers_1 = require("../../utils/get-id-from-create-headers");
const callGetSourceByIdAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.sources}/${args.id}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetSourceByIdAPI' });
        return handleErrorResult;
    }
});
exports.callGetSourceByIdAPI = callGetSourceByIdAPI;
const callGetSourcesAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const params = query_string_1.default.stringify(args);
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.sources}?${params}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        logger_1.default.error('callGetSourcesAPIERRRPR', error);
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetSourcesAPI' });
        return handleErrorResult;
    }
});
exports.callGetSourcesAPI = callGetSourcesAPI;
const callCreateSourceAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().post(api_1.URLS.sources, args, {
            headers: {
                Authorization: context.authorization,
            },
        });
        const id = (0, get_id_from_create_headers_1.getIdFromCreateHeaders)({ headers: response.headers });
        if (id) {
            return (0, exports.callGetSourceByIdAPI)({ id }, context);
        }
        return null;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callCreateSourceAPI' });
        return handleErrorResult;
    }
});
exports.callCreateSourceAPI = callCreateSourceAPI;
const callUpdateSourceAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { _eTag } = args, payload = __rest(args, ["_eTag"]);
        const updateResponse = yield (0, axios_instances_1.createPlatformAxiosInstance)().patch(`${api_1.URLS.sources}/${args.id}`, payload, {
            headers: {
                Authorization: context.authorization,
                'If-Match': _eTag,
            },
        });
        if (updateResponse) {
            return (0, exports.callGetSourceByIdAPI)({ id: args.id }, context);
        }
        return errors_1.default.generateUserInputError(traceId);
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callUpdateSourceAPI' });
        return handleErrorResult;
    }
});
exports.callUpdateSourceAPI = callUpdateSourceAPI;
//# sourceMappingURL=api.js.map