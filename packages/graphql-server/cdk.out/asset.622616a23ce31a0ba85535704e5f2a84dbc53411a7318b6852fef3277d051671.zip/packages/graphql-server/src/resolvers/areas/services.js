"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateArea = exports.createArea = exports.getAreas = exports.getAreaById = void 0;
const api_1 = require("./api");
const getAreaById = (args, context) => {
    const area = (0, api_1.callGetAreaByIdAPI)(args, context);
    return area;
};
exports.getAreaById = getAreaById;
const getAreas = (args, context) => {
    const areas = (0, api_1.callGetAreasAPI)(args, context);
    return areas;
};
exports.getAreas = getAreas;
const createArea = (args, context) => {
    const createResult = (0, api_1.callCreateAreaAPI)(args, context);
    return createResult;
};
exports.createArea = createArea;
const updateArea = (args, context) => {
    const updateResult = (0, api_1.callUpdateAreaAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateArea = updateArea;
const areaServices = {
    getAreaById: exports.getAreaById,
    getAreas: exports.getAreas,
    createArea: exports.createArea,
    updateArea: exports.updateArea,
};
exports.default = areaServices;
//# sourceMappingURL=services.js.map