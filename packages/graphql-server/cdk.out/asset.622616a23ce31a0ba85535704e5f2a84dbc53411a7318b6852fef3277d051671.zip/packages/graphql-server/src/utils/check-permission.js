"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkPermission = void 0;
const checkPermission = (context) => {
    const isPermit = !!context.authorization;
    return isPermit;
};
exports.checkPermission = checkPermission;
//# sourceMappingURL=check-permission.js.map