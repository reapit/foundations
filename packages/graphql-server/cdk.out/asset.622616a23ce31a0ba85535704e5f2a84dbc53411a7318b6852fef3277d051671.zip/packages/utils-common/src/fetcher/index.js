"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractNetworkErrString = exports.getDefaultFetchDetailValue = exports.getDefaultFetchListValue = exports.fetcher = exports.fetcherWithBlob = exports.fetcherWithReturnHeader = exports.fetcherWithRawUrl = exports.genErr = exports.FetchError = void 0;
const error_messages_1 = require("../constants/error-messages");
class FetchError extends Error {
    constructor(message, response) {
        super(message);
        this.message = message;
        this.response = response;
        Object.setPrototypeOf(this, new.target.prototype); // restore prototype chain
        this.name = this.constructor.name;
        this.status = this.constructor.status;
        this.message = message;
        if (Error.captureStackTrace && typeof Error.captureStackTrace === 'function') {
            Error.captureStackTrace(this, this.constructor);
        }
        this.response = response;
    }
}
exports.FetchError = FetchError;
const genErr = (res_1, _a) => __awaiter(void 0, [res_1, _a], void 0, function* (res, { method, url }) {
    const genErrResponse = () => __awaiter(void 0, void 0, void 0, function* () {
        try {
            const response = yield res.json();
            return response;
        }
        catch (err) {
            return res;
        }
    });
    const errRes = yield genErrResponse();
    const error = new FetchError(`Foundations API error: Status: ${res.status} Method: ${method} Path: ${url} ${JSON.stringify(errRes)}`);
    error.status = res.status;
    error.response = errRes;
    return error;
});
exports.genErr = genErr;
/**
 * allow fetch from raw url string (instead of api - base domal, url - path)
 */
const fetcherWithRawUrl = (_b) => __awaiter(void 0, [_b], void 0, function* ({ url, method, body, headers, }) {
    const res = yield fetch(url, {
        headers,
        method,
        body: JSON.stringify(body),
    });
    if (res.status < 400) {
        const jsonRes = yield res.json();
        return jsonRes;
    }
    const err = yield (0, exports.genErr)(res, { url, method });
    throw err;
});
exports.fetcherWithRawUrl = fetcherWithRawUrl;
/**
 * return headers of responose
 */
const fetcherWithReturnHeader = (_c) => __awaiter(void 0, [_c], void 0, function* ({ api, url, method, body, headers, }) {
    const path = `${api}${url}`;
    const res = yield fetch(path, {
        headers,
        method,
        body: JSON.stringify(body),
    });
    if (res.status < 400) {
        return res.headers;
    }
    const err = yield (0, exports.genErr)(res, { url, method });
    throw err;
});
exports.fetcherWithReturnHeader = fetcherWithReturnHeader;
const fetcherWithBlob = (_d) => __awaiter(void 0, [_d], void 0, function* ({ api, url, method, body, headers, }) {
    const path = `${api}${url}`;
    const res = yield fetch(path, {
        headers,
        method,
        body: JSON.stringify(body),
    });
    if (res.status < 400) {
        try {
            const blob = yield res.blob();
            return blob;
        }
        catch (err) {
            const error = new FetchError("Can't convert response to blob. Error:", err.message);
            console.error(error.message);
            throw error;
        }
    }
    const err = yield (0, exports.genErr)(res, { url, method });
    throw err;
});
exports.fetcherWithBlob = fetcherWithBlob;
const fetcher = (_e) => __awaiter(void 0, [_e], void 0, function* ({ api, url, method, body, headers, }) {
    const path = `${api}${url}`;
    const res = yield fetch(path, {
        headers,
        method,
        body: JSON.stringify(body),
    });
    if (res.status < 400) {
        try {
            const jsonVal = yield res.json();
            return jsonVal;
        }
        catch (err) {
            return res.ok;
        }
    }
    const err = yield (0, exports.genErr)(res, { url, method });
    throw err;
});
exports.fetcher = fetcher;
const getDefaultFetchListValue = () => (Object.assign(Object.assign({}, (0, exports.getDefaultFetchDetailValue)()), { data: [], totalCount: 0, pageSize: 0, pageNumber: 0, pageCount: 0 }));
exports.getDefaultFetchListValue = getDefaultFetchListValue;
const getDefaultFetchDetailValue = () => ({
    isLoading: false,
    errorMessage: '',
    data: null,
});
exports.getDefaultFetchDetailValue = getDefaultFetchDetailValue;
/**
 * return standard description error string
 * or DEFAULT_SERVER_ERROR
 */
const extractNetworkErrString = (err) => {
    var _a, _b;
    /**
     * response contain standard error object
     * {
     *   dataTime,
     *   description,
     *   statusCode
     * }
     */
    const standardErrDescriptionData = (_a = err === null || err === void 0 ? void 0 : err.response) === null || _a === void 0 ? void 0 : _a.description;
    if ((_b = err === null || err === void 0 ? void 0 : err.response) === null || _b === void 0 ? void 0 : _b.description) {
        return standardErrDescriptionData;
    }
    if (typeof err === 'string') {
        return err;
    }
    return error_messages_1.errorMessages.DEFAULT_SERVER_ERROR;
};
exports.extractNetworkErrString = extractNetworkErrString;
//# sourceMappingURL=index.js.map