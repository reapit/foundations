"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.currencySymbolMapper = void 0;
const currencySymbolMapper = (currency) => {
    switch (currency) {
        case 'GBP':
            return '£';
        case 'EUR':
            return '€';
        case 'USD':
            return '$';
        case 'AUD':
            return 'A$';
        default:
            return currency;
    }
};
exports.currencySymbolMapper = currencySymbolMapper;
//# sourceMappingURL=index.js.map