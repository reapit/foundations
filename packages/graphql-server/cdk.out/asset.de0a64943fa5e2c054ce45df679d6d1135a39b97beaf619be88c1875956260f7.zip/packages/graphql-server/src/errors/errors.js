"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateNotFoundError = exports.generateInternalServerError = exports.generateForbiddenError = exports.generateValidationError = exports.generatePreconditionError = exports.generateUnprocessableError = exports.generateUserInputError = exports.generateAuthenticationError = exports.errorMessages = void 0;
const apollo_server_lambda_1 = require("apollo-server-lambda");
exports.errorMessages = {
    notAuthorized: '401 - Not Authorized',
    badRequest: '400 - Bad Request',
    notFound: '404 - Not Found',
    forbidden: '403 - Forbidden',
    precondion: '412 - Precondition Failed',
    unprocessable: '422 - Unprocessable Entity',
    internalServer: '500 - Internal Server Error',
};
const generateAuthenticationError = (traceId) => {
    const error = new apollo_server_lambda_1.AuthenticationError(`${traceId || ''} - ${exports.errorMessages.notAuthorized}`);
    return error;
};
exports.generateAuthenticationError = generateAuthenticationError;
const generateUserInputError = (traceId) => {
    const error = new apollo_server_lambda_1.UserInputError(`${traceId || ''} - ${exports.errorMessages.badRequest}`);
    return error;
};
exports.generateUserInputError = generateUserInputError;
const generateUnprocessableError = (traceId, reapitBackendError) => {
    const error = new apollo_server_lambda_1.UserInputError(`${traceId || ''} - ${exports.errorMessages.unprocessable}`);
    if (error.extensions) {
        error.extensions.validationErrors = reapitBackendError;
    }
    return error;
};
exports.generateUnprocessableError = generateUnprocessableError;
const generatePreconditionError = (traceId) => {
    const error = new apollo_server_lambda_1.UserInputError(`${traceId || ''} - ${exports.errorMessages.precondion}`);
    return error;
};
exports.generatePreconditionError = generatePreconditionError;
const generateValidationError = (traceId) => {
    const error = new apollo_server_lambda_1.ValidationError(`${traceId || ''} - ${exports.errorMessages.badRequest}`);
    return error;
};
exports.generateValidationError = generateValidationError;
const generateForbiddenError = (traceId) => {
    const error = new apollo_server_lambda_1.ForbiddenError(`${traceId || ''} - ${exports.errorMessages.forbidden}`);
    return error;
};
exports.generateForbiddenError = generateForbiddenError;
const generateInternalServerError = (traceId) => {
    const error = new apollo_server_lambda_1.ApolloError(`${traceId || ''} - ${exports.errorMessages.internalServer}`, 'INTERNAL_SERVER_ERROR');
    return error;
};
exports.generateInternalServerError = generateInternalServerError;
const generateNotFoundError = (traceId) => {
    const error = new apollo_server_lambda_1.ApolloError(`${traceId || ''} - ${exports.errorMessages.notFound}`, 'NOT_FOUND');
    return error;
};
exports.generateNotFoundError = generateNotFoundError;
const errors = {
    generateAuthenticationError: exports.generateAuthenticationError,
    generateUnprocessableError: exports.generateUnprocessableError,
    generateValidationError: exports.generateValidationError,
    generateUserInputError: exports.generateUserInputError,
    generatePreconditionError: exports.generatePreconditionError,
    generateForbiddenError: exports.generateForbiddenError,
    generateInternalServerError: exports.generateInternalServerError,
    generateNotFoundError: exports.generateNotFoundError,
};
exports.default = errors;
//# sourceMappingURL=errors.js.map