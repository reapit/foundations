"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deletePropertyImage = exports.updatePropertyImage = exports.createPropertyImage = exports.getPropertyImages = exports.getPropertyImageById = void 0;
const api_1 = require("./api");
const getPropertyImageById = (args, context) => {
    const property = (0, api_1.callGetPropertyImageByIdAPI)(args, context);
    return property;
};
exports.getPropertyImageById = getPropertyImageById;
const getPropertyImages = (args, context) => {
    const propertyImages = (0, api_1.callGetPropertyImagesAPI)(args, context);
    return propertyImages;
};
exports.getPropertyImages = getPropertyImages;
const createPropertyImage = (args, context) => {
    const createResult = (0, api_1.callCreatePropertyImageAPI)(args, context);
    return createResult;
};
exports.createPropertyImage = createPropertyImage;
const updatePropertyImage = (args, context) => {
    const updateResult = (0, api_1.callUpdatePropertyImageAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updatePropertyImage = updatePropertyImage;
const deletePropertyImage = (args, context) => {
    const deleteResult = (0, api_1.callDeletePropertyImageAPI)(Object.assign({}, args), context);
    return deleteResult;
};
exports.deletePropertyImage = deletePropertyImage;
const propertyServices = {
    getPropertyImageById: exports.getPropertyImageById,
    getPropertyImages: exports.getPropertyImages,
    createPropertyImage: exports.createPropertyImage,
    updatePropertyImage: exports.updatePropertyImage,
    deletePropertyImage: exports.deletePropertyImage,
};
exports.default = propertyServices;
//# sourceMappingURL=services.js.map