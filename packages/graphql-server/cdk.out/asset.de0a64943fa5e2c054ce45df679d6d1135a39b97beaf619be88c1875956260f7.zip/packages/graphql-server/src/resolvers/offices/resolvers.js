"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateOffice = exports.mutationCreateOffice = exports.queryGetOffices = exports.queryGetOfficeById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetOfficeById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getOfficeById(args, context);
});
exports.queryGetOffices = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getOffices(args, context);
});
exports.mutationCreateOffice = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createOffice(args, context);
});
exports.mutationUpdateOffice = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateOffice(args, context);
});
exports.default = {
    Query: {
        GetOfficeById: exports.queryGetOfficeById,
        GetOffices: exports.queryGetOffices,
    },
    Mutation: {
        CreateOffice: exports.mutationCreateOffice,
        UpdateOffice: exports.mutationUpdateOffice,
    },
};
//# sourceMappingURL=resolvers.js.map