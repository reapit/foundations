"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateContact = exports.mutationCreateContact = exports.queryGetContacts = exports.queryGetContactById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetContactById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getContactById(args, context);
});
exports.queryGetContacts = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getContacts(args, context);
});
exports.mutationCreateContact = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createContact(args, context);
});
exports.mutationUpdateContact = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateContact(args, context);
});
exports.default = {
    Query: {
        GetContactById: exports.queryGetContactById,
        GetContacts: exports.queryGetContacts,
    },
    Mutation: {
        CreateContact: exports.mutationCreateContact,
        UpdateContact: exports.mutationUpdateContact,
    },
};
//# sourceMappingURL=resolvers.js.map