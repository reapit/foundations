"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateOffer = exports.createOffer = exports.getOffers = exports.getOfferById = void 0;
const api_1 = require("./api");
const getOfferById = (args, context) => {
    const Offer = (0, api_1.callGetOfferByIdAPI)(args, context);
    return Offer;
};
exports.getOfferById = getOfferById;
const getOffers = (args, context) => {
    const Offers = (0, api_1.callGetOffersAPI)(args, context);
    return Offers;
};
exports.getOffers = getOffers;
const createOffer = (args, context) => {
    const createResult = (0, api_1.callCreateOfferAPI)(args, context);
    return createResult;
};
exports.createOffer = createOffer;
const updateOffer = (args, context) => {
    const updateResult = (0, api_1.callUpdateOfferAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateOffer = updateOffer;
const OfferServices = {
    getOfferById: exports.getOfferById,
    getOffers: exports.getOffers,
    createOffer: exports.createOffer,
    updateOffer: exports.updateOffer,
};
exports.default = OfferServices;
//# sourceMappingURL=services.js.map