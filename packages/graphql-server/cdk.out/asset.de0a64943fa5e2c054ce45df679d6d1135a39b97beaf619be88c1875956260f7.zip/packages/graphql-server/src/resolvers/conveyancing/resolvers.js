"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationDeleteDownwardLinkModel = exports.mutationDeleteUpwardLinkModel = exports.mutationCreateDownwardLinkModel = exports.mutationCreateUpwardLinkModel = exports.mutationUpdateConveyancing = exports.queryGetConveyancingChain = exports.queryGetConveyancing = exports.queryGetConveyancingById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetConveyancingById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getConveyancingById(args, context);
});
exports.queryGetConveyancing = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getConveyancing(args, context);
});
exports.queryGetConveyancingChain = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getConveyancingChain(args, context);
});
exports.mutationUpdateConveyancing = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateConveyancing(args, context);
});
exports.mutationCreateUpwardLinkModel = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createUpwardLinkModel(args, context);
});
exports.mutationCreateDownwardLinkModel = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createDownwardLinkModel(args, context);
});
exports.mutationDeleteUpwardLinkModel = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.deleteUpwardLinkModel(args, context);
});
exports.mutationDeleteDownwardLinkModel = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.deleteDownwardLinkModel(args, context);
});
exports.default = {
    Query: {
        GetConveyancingById: exports.queryGetConveyancingById,
        GetConveyancing: exports.queryGetConveyancing,
        GetConveyancingChain: exports.queryGetConveyancingChain,
    },
    Mutation: {
        UpdateConveyancing: exports.mutationUpdateConveyancing,
        CreateDownwardLinkModel: exports.mutationCreateDownwardLinkModel,
        CreateUpwardLinkModel: exports.mutationCreateUpwardLinkModel,
        DeleteDownwardLinkModel: exports.mutationDeleteDownwardLinkModel,
        DeleteUpwardLinkModel: exports.mutationDeleteUpwardLinkModel,
    },
};
//# sourceMappingURL=resolvers.js.map