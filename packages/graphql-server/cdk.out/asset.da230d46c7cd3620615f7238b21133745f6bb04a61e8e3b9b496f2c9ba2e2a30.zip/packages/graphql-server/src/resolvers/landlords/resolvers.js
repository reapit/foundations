"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateLandlord = exports.mutationDeleteLandlordRelationship = exports.mutationCreateLandlordRelationship = exports.mutationCreateLandlord = exports.queryGetLandlordRelationships = exports.queryGetLandlordRelationshipById = exports.queryGetLandlords = exports.queryGetLandlordById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetLandlordById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getLandlordById(args, context);
});
exports.queryGetLandlords = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getLandlords(args, context);
});
exports.queryGetLandlordRelationshipById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getLandlordRelationshipById(args, context);
});
exports.queryGetLandlordRelationships = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getLandlordRelationships(args, context);
});
exports.mutationCreateLandlord = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createLandlord(args, context);
});
exports.mutationCreateLandlordRelationship = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createLandlordRelationship(args, context);
});
exports.mutationDeleteLandlordRelationship = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.deleteLandlordRelationship(args, context);
});
exports.mutationUpdateLandlord = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateLandlord(args, context);
});
exports.default = {
    Query: {
        GetLandlords: exports.queryGetLandlords,
        GetLandlordById: exports.queryGetLandlordById,
        GetLandlordRelationships: exports.queryGetLandlordRelationships,
        GetLandlordRelationshipById: exports.queryGetLandlordRelationshipById,
    },
    Mutation: {
        CreateLandlord: exports.mutationCreateLandlord,
        CreateLandlordRelationship: exports.mutationCreateLandlordRelationship,
        DeleteLandlordRelationship: exports.mutationDeleteLandlordRelationship,
        UpdateLandlord: exports.mutationUpdateLandlord,
    },
};
//# sourceMappingURL=resolvers.js.map