"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isIOS = exports.isAndroid = void 0;
const isAndroid = () => {
    return navigator.userAgent.toLowerCase().indexOf('android') > -1;
};
exports.isAndroid = isAndroid;
const isIOS = () => {
    return /iPad|iPhone|iPod/.test(navigator.userAgent);
};
exports.isIOS = isIOS;
//# sourceMappingURL=index.js.map