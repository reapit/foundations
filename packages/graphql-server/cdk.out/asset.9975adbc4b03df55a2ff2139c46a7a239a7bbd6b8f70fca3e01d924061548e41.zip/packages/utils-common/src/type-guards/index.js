"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isTruthy = void 0;
const isTruthy = (value) => {
    return Boolean(value);
};
exports.isTruthy = isTruthy;
//# sourceMappingURL=index.js.map