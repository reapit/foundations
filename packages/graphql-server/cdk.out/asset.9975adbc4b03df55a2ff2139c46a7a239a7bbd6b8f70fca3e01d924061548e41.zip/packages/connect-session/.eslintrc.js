const { baseEslint } = require('@reapit/ts-scripts')

module.exports = baseEslint
