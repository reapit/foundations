"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationCreateEnquiry = exports.queryGetEnquiries = exports.queryGetEnquiryById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetEnquiryById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getEnquiryById(args, context);
});
exports.queryGetEnquiries = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getEnquiries(args, context);
});
exports.mutationCreateEnquiry = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createEnquiry(args, context);
});
exports.default = {
    Query: {
        GetEnquiryById: exports.queryGetEnquiryById,
        GetEnquiries: exports.queryGetEnquiries,
    },
    Mutation: {
        CreateEnquiry: exports.mutationCreateEnquiry,
    },
};
//# sourceMappingURL=resolvers.js.map