"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateNegotiator = exports.createNegotiator = exports.getNegotiators = exports.getNegotiatorById = void 0;
const api_1 = require("./api");
const getNegotiatorById = (args, context) => {
    const negotiator = (0, api_1.callGetNegotiatorByIdAPI)(args, context);
    return negotiator;
};
exports.getNegotiatorById = getNegotiatorById;
const getNegotiators = (args, context) => {
    const negotiators = (0, api_1.callGetNegotiatorsAPI)(args, context);
    return negotiators;
};
exports.getNegotiators = getNegotiators;
const createNegotiator = (args, context) => {
    const createResult = (0, api_1.callCreateNegotiatorAPI)(args, context);
    return createResult;
};
exports.createNegotiator = createNegotiator;
const updateNegotiator = (args, context) => {
    const updateResult = (0, api_1.callUpdateNegotiatorAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateNegotiator = updateNegotiator;
const negotiatorServices = {
    getNegotiatorById: exports.getNegotiatorById,
    getNegotiators: exports.getNegotiators,
    createNegotiator: exports.createNegotiator,
    updateNegotiator: exports.updateNegotiator,
};
exports.default = negotiatorServices;
//# sourceMappingURL=services.js.map