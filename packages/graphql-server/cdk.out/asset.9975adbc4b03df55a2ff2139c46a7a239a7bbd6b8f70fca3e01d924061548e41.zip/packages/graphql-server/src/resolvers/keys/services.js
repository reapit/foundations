"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateKeyMovement = exports.createKeyMovement = exports.getKeyMovement = exports.getKeyMovements = exports.createKey = exports.getKeyById = exports.getKeysByPropertyId = void 0;
const api_1 = require("./api");
const api_2 = require("../configurations/api");
const convertPlatformKeysToKeys = (keys, context) => __awaiter(void 0, void 0, void 0, function* () {
    const types = yield (0, api_2.callGetConfigurationsByTypeApi)({ type: 'keyTypes' }, context);
    return Promise.all(keys.map((key) => __awaiter(void 0, void 0, void 0, function* () {
        return (Object.assign(Object.assign({}, key), { office: yield context.dataLoader.officeLoader.load(key.officeId), type: types.find((t) => t.id === key.typeId), status: key.status }));
    })));
});
const getKeysByPropertyId = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const keys = yield (0, api_1.callGetPropertyKeysAPI)(args, context);
    return convertPlatformKeysToKeys(keys._embedded, context);
});
exports.getKeysByPropertyId = getKeysByPropertyId;
const getKeyById = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const key = yield (0, api_1.callGetKeyAPI)(args, context);
    const [keyResult] = yield convertPlatformKeysToKeys([key], context);
    return keyResult;
});
exports.getKeyById = getKeyById;
const createKey = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const key = yield (0, api_1.callCreateKeyAPI)(args, context);
    const [keyResult] = yield convertPlatformKeysToKeys([key], context);
    return keyResult;
});
exports.createKey = createKey;
const convertPlatformMovementToMovement = (movements, context) => __awaiter(void 0, void 0, void 0, function* () {
    return Promise.all(movements.map((movement) => __awaiter(void 0, void 0, void 0, function* () {
        return (Object.assign(Object.assign({}, movement), { checkInNegotiator: movement.checkInNegotiatorId && (yield context.dataLoader.negotiatorLoader.load(movement.checkInNegotiatorId)), checkOutNegotiator: movement.checkOutNegotiatorId &&
                (yield context.dataLoader.negotiatorLoader.load(movement.checkOutNegotiatorId)), checkOutToContact: movement.checkOutToType === 'contact' &&
                movement.checkOutToId &&
                (yield context.dataLoader.contactLoader.load(movement.checkOutToId)), checkOutToNegotiator: movement.checkOutToType === 'negotiator' &&
                movement.checkOutToId &&
                (yield context.dataLoader.negotiatorLoader.load(movement.checkOutToId)) }));
    })));
});
const getKeyMovements = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const movements = yield (0, api_1.callGetKeyMovementsAPI)(args, context);
    return yield convertPlatformMovementToMovement(movements._embedded, context);
});
exports.getKeyMovements = getKeyMovements;
const getKeyMovement = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const movement = yield (0, api_1.callGetKeyMovementAPI)(args, context);
    const [convertedMovement] = yield convertPlatformMovementToMovement([movement], context);
    return convertedMovement;
});
exports.getKeyMovement = getKeyMovement;
const createKeyMovement = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const movement = yield (0, api_1.callCreateKeyMovementAPI)(args, context);
    const [convertedMovement] = yield convertPlatformMovementToMovement([movement], context);
    return convertedMovement;
});
exports.createKeyMovement = createKeyMovement;
const updateKeyMovement = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const movement = yield (0, api_1.callUpdateKeyMovementAPI)(args, context);
    const [convertedMovement] = yield convertPlatformMovementToMovement([movement], context);
    return convertedMovement;
});
exports.updateKeyMovement = updateKeyMovement;
const propertyServices = {
    getKeysByPropertyId: exports.getKeysByPropertyId,
    getKeyById: exports.getKeyById,
    createKey: exports.createKey,
    getKeyMovements: exports.getKeyMovements,
    getKeyMovement: exports.getKeyMovement,
    createKeyMovement: exports.createKeyMovement,
    updateKeyMovement: exports.updateKeyMovement,
};
exports.default = propertyServices;
//# sourceMappingURL=services.js.map