"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteTenancyCheck = exports.updateTenancyCheck = exports.createTenancyCheck = exports.createTenancy = exports.getTenancyRelationships = exports.getTenancyChecks = exports.getTenancyCheckById = exports.getTenancies = exports.getTenancyById = void 0;
const api_1 = require("./api");
const getTenancyById = (args, context) => {
    const tenancy = (0, api_1.callGetTenancyByIdAPI)(args, context);
    return tenancy;
};
exports.getTenancyById = getTenancyById;
const getTenancies = (args, context) => {
    const tenancies = (0, api_1.callGetTenanciesAPI)(args, context);
    return tenancies;
};
exports.getTenancies = getTenancies;
const getTenancyCheckById = (args, context) => {
    const tenancyCheck = (0, api_1.callGetTenancyCheckByIdAPI)(args, context);
    return tenancyCheck;
};
exports.getTenancyCheckById = getTenancyCheckById;
const getTenancyChecks = (args, context) => {
    const tenancyChecks = (0, api_1.callGetTenancyChecksAPI)(args, context);
    return tenancyChecks;
};
exports.getTenancyChecks = getTenancyChecks;
const getTenancyRelationships = (args, context) => {
    const tenancyRelationships = (0, api_1.callGetTenancyRelationshipsAPI)(args, context);
    return tenancyRelationships;
};
exports.getTenancyRelationships = getTenancyRelationships;
const createTenancy = (args, context) => {
    const createdTenancy = (0, api_1.callCreateTenancyAPI)(args, context);
    return createdTenancy;
};
exports.createTenancy = createTenancy;
const createTenancyCheck = (args, context) => {
    const createdTenancyCheck = (0, api_1.callCreateTenancyCheckAPI)(args, context);
    return createdTenancyCheck;
};
exports.createTenancyCheck = createTenancyCheck;
const updateTenancyCheck = (args, context) => {
    const updatedTenancyCheck = (0, api_1.callUpdateTenancyCheckAPI)(args, context);
    return updatedTenancyCheck;
};
exports.updateTenancyCheck = updateTenancyCheck;
const deleteTenancyCheck = (args, context) => {
    const isDeleted = (0, api_1.callDeleteTenancyCheckAPI)(args, context);
    return isDeleted;
};
exports.deleteTenancyCheck = deleteTenancyCheck;
const tenancyServices = {
    getTenancyById: exports.getTenancyById,
    getTenancies: exports.getTenancies,
    getTenancyChecks: exports.getTenancyChecks,
    getTenancyCheckById: exports.getTenancyCheckById,
    getTenancyRelationships: exports.getTenancyRelationships,
    createTenancy: exports.createTenancy,
    createTenancyCheck: exports.createTenancyCheck,
    deleteTenancyCheck: exports.deleteTenancyCheck,
    updateTenancyCheck: exports.updateTenancyCheck,
};
exports.default = tenancyServices;
//# sourceMappingURL=services.js.map