"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatError = void 0;
const formatError = (error) => {
    var _a;
    if (process.env.NODE_ENV === 'production') {
        return { message: error.message, extensions: { code: (_a = error.extensions) === null || _a === void 0 ? void 0 : _a.code } };
    }
    return error;
};
exports.formatError = formatError;
//# sourceMappingURL=format.error.js.map