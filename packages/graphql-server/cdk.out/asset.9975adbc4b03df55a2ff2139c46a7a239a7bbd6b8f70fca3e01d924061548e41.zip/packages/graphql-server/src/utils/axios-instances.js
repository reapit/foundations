"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPlatformAxiosInstance = void 0;
const axios_1 = __importDefault(require("axios"));
const axios_retry_1 = __importDefault(require("axios-retry"));
const api_1 = require("../constants/api");
const retryConfig = {
    retries: 10,
    retryDelay: axios_retry_1.default.exponentialDelay,
    retryCondition: (error) => {
        return error.response && error.response.status === 429;
    },
};
const createPlatformAxiosInstance = (customRetryConfig) => {
    const instance = axios_1.default.create({
        baseURL: process.env.PLATFORM_API_BASE_URL,
        headers: {
            'Content-Type': 'application/json',
            'api-version': api_1.API_VERSION,
        },
    });
    (0, axios_retry_1.default)(instance, Object.assign(Object.assign({}, retryConfig), customRetryConfig));
    return instance;
};
exports.createPlatformAxiosInstance = createPlatformAxiosInstance;
//# sourceMappingURL=axios-instances.js.map