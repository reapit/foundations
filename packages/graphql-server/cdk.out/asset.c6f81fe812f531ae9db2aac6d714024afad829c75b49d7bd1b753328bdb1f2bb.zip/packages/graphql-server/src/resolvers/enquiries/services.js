"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEnquiry = exports.getEnquiries = exports.getEnquiryById = void 0;
const api_1 = require("./api");
const getEnquiryById = (args, context) => {
    const enquirie = (0, api_1.callGetEnquiryByIdAPI)(args, context);
    return enquirie;
};
exports.getEnquiryById = getEnquiryById;
const getEnquiries = (args, context) => {
    const enquiries = (0, api_1.callGetEnquiriesAPI)(args, context);
    return enquiries;
};
exports.getEnquiries = getEnquiries;
const createEnquiry = (args, context) => {
    const createResult = (0, api_1.callCreateEnquiryAPI)(args, context);
    return createResult;
};
exports.createEnquiry = createEnquiry;
const enquirieServices = {
    getEnquiryById: exports.getEnquiryById,
    getEnquiries: exports.getEnquiries,
    createEnquiry: exports.createEnquiry,
};
exports.default = enquirieServices;
//# sourceMappingURL=services.js.map