"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryGetPropertyKeysResolver = exports.queryGetKeyMovements = exports.mutationUpdateKeyMovement = exports.mutationCreateKeyMovement = exports.mutationCreateKey = exports.queryGetKey = exports.queryGetPropertyKeys = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetPropertyKeys = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getKeysByPropertyId(args, context);
});
exports.queryGetKey = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getKeyById(args, context);
});
exports.mutationCreateKey = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createKey(args, context);
});
exports.mutationCreateKeyMovement = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createKeyMovement(args, context);
});
exports.mutationUpdateKeyMovement = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateKeyMovement(args, context);
});
exports.queryGetKeyMovements = (0, utils_1.resolverHandler)((parent, args, context) => {
    return services_1.default.getKeyMovements({ keyId: parent.id, propertyId: parent.propertyId }, context);
});
exports.queryGetPropertyKeysResolver = (0, utils_1.resolverHandler)((parent, args, context) => {
    return services_1.default.getKeysByPropertyId({ propertyId: parent.id }, context);
});
exports.default = {
    Query: {
        GetPropertyKeys: exports.queryGetPropertyKeys,
        GetKey: exports.queryGetKey,
    },
    Mutation: {
        CreateKey: exports.mutationCreateKey,
        CreateKeyMovement: exports.mutationCreateKeyMovement,
        UpdateKeyMovement: exports.mutationUpdateKeyMovement,
    },
    KeyModel: {
        movements: exports.queryGetKeyMovements,
    },
    PropertyModel: {
        keys: exports.queryGetPropertyKeysResolver,
    },
};
//# sourceMappingURL=resolvers.js.map