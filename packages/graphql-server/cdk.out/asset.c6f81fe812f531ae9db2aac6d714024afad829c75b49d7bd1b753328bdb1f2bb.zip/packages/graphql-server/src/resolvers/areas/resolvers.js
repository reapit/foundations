"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateArea = exports.mutationCreateArea = exports.queryGetAreas = exports.queryGetAreaById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetAreaById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getAreaById(args, context);
});
exports.queryGetAreas = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getAreas(args, context);
});
exports.mutationCreateArea = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createArea(args, context);
});
exports.mutationUpdateArea = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateArea(args, context);
});
exports.default = {
    Query: {
        GetAreaById: exports.queryGetAreaById,
        GetAreas: exports.queryGetAreas,
    },
    Mutation: {
        CreateArea: exports.mutationCreateArea,
        UpdateArea: exports.mutationUpdateArea,
    },
};
//# sourceMappingURL=resolvers.js.map