"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateOffer = exports.mutationCreateOffer = exports.queryGetOffers = exports.queryGetOfferById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetOfferById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getOfferById(args, context);
});
exports.queryGetOffers = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getOffers(args, context);
});
exports.mutationCreateOffer = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createOffer(args, context);
});
exports.mutationUpdateOffer = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateOffer(args, context);
});
exports.default = {
    Query: {
        GetOfferById: exports.queryGetOfferById,
        GetOffers: exports.queryGetOffers,
    },
    Mutation: {
        CreateOffer: exports.mutationCreateOffer,
        UpdateOffer: exports.mutationUpdateOffer,
    },
};
//# sourceMappingURL=resolvers.js.map