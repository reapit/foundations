"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateTenancyCheck = exports.mutationDeleteTenancyCheck = exports.mutationCreateTenancyCheck = exports.mutationCreateTenancy = exports.queryGetTenancyRelationships = exports.queryGetTenancyChecks = exports.queryGetTenancyCheckById = exports.queryGetTenancies = exports.queryGetTenancyById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetTenancyById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getTenancyById(args, context);
});
exports.queryGetTenancies = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getTenancies(args, context);
});
exports.queryGetTenancyCheckById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getTenancyCheckById(args, context);
});
exports.queryGetTenancyChecks = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getTenancyChecks(args, context);
});
exports.queryGetTenancyRelationships = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getTenancyRelationships(args, context);
});
exports.mutationCreateTenancy = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createTenancy(args, context);
});
exports.mutationCreateTenancyCheck = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createTenancyCheck(args, context);
});
exports.mutationDeleteTenancyCheck = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.deleteTenancyCheck(args, context);
});
exports.mutationUpdateTenancyCheck = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateTenancyCheck(args, context);
});
exports.default = {
    Query: {
        GetTenancies: exports.queryGetTenancies,
        GetTenancyById: exports.queryGetTenancyById,
        GetTenancyRelationships: exports.queryGetTenancyRelationships,
        GetTenancyChecks: exports.queryGetTenancyChecks,
        GetTenancyCheckById: exports.queryGetTenancyCheckById,
    },
    Mutation: {
        CreateTenancy: exports.mutationCreateTenancy,
        CreateTenancyCheck: exports.mutationCreateTenancyCheck,
        DeleteTenancyCheck: exports.mutationDeleteTenancyCheck,
        UpdateTenancyCheck: exports.mutationUpdateTenancyCheck,
    },
};
//# sourceMappingURL=resolvers.js.map