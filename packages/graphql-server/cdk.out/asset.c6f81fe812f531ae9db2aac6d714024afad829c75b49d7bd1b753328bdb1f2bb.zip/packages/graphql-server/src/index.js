"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = require("apollo-server-lambda");
const graphql_common_1 = require("./graphql-common");
const server = new apollo_server_lambda_1.ApolloServer(graphql_common_1.config);
exports.graphqlHandler = server.createHandler();
//# sourceMappingURL=index.js.map