"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HEADERS = exports.URLS = exports.API_VERSION = void 0;
exports.API_VERSION = '2020-01-31';
exports.URLS = {
    applicants: '/applicants',
    areas: '/areas',
    contacts: '/contacts',
    offices: '/offices',
    appointments: '/appointments',
    identityChecks: '/identityChecks',
    negotiators: '/negotiators',
    properties: '/properties',
    configurations: '/configuration',
    propertyImages: '/propertyImages',
    companies: '/companies',
    tasks: '/tasks',
    tenancies: '/tenancies',
    offers: '/offers',
    vendors: '/vendors',
    conveyancing: '/conveyancing',
    landlords: '/landlords',
    departments: '/departments',
    sources: '/sources',
    journalEntries: 'journalEntries',
    enquiries: '/enquiries',
    worksOrders: '/worksOrders',
    documents: '/documents',
};
exports.HEADERS = {
    'Content-Type': 'application/json',
    'api-version': exports.API_VERSION,
};
//# sourceMappingURL=api.js.map