"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorMessages = void 0;
exports.errorMessages = {
    DEFAULT_SERVER_ERROR: 'Something went wrong fetching data',
    SUBSCRIPTION_MULTIPLE_DEVELOPER: 'Can not select more than 1 developer',
};
//# sourceMappingURL=error-messages.js.map