"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getParamsFromPath = exports.setQueryParams = void 0;
const setQueryParams = (params) => {
    if (!Object.keys(params).length)
        return '';
    return Object.keys(params)
        .filter((key) => params[key] !== undefined && params[key] !== null && params[key] !== '')
        .map((key) => {
        if (Array.isArray(params[key])) {
            return params[key].map((value) => `${key}=${value}`).join('&');
        }
        return `${key}=${params[key]}`;
    })
        .join('&');
};
exports.setQueryParams = setQueryParams;
const getParamsFromPath = (search) => {
    const output = {};
    const params = new URLSearchParams(search);
    params.forEach((value, key) => {
        if (key === 'page') {
            const pageParam = Number(value);
            return (output.page = !isNaN(pageParam) && pageParam > 0 ? pageParam : 1);
        }
        output[key] = value || '';
    });
    return output;
};
exports.getParamsFromPath = getParamsFromPath;
//# sourceMappingURL=index.js.map