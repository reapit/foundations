const { baseBabel } = require('@reapit/ts-scripts')

module.exports = {
  ...baseBabel,
}
