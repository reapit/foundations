"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = exports.levels = void 0;
const winston_1 = __importDefault(require("winston"));
const utils_node_1 = require("@reapit/utils-node");
exports.levels = {
    error: 0,
    warn: 1,
    info: 2,
    http: 3,
    verbose: 4,
    debug: 5,
    silly: 6,
};
exports.logger = winston_1.default.createLogger({
    format: winston_1.default.format.combine(winston_1.default.format.json()),
    defaultMeta: { service: 'graphql-server' },
    exitOnError: false,
    transports: [
        new winston_1.default.transports.Console({
            format: winston_1.default.format.combine(winston_1.default.format.json()),
        }),
    ],
});
exports.logger.error = (0, utils_node_1.createWistonLoggerErrorFn)(exports.logger.error);
exports.default = exports.logger;
//# sourceMappingURL=logger.js.map