"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryGetDepartments = exports.queryGetDepartmentById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetDepartmentById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getDepartmentById(args, context);
});
exports.queryGetDepartments = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getDepartments(args, context);
});
exports.default = {
    Query: {
        GetDepartmentById: exports.queryGetDepartmentById,
        GetDepartments: exports.queryGetDepartments,
    },
};
//# sourceMappingURL=resolvers.js.map