"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteUpwardLinkModel = exports.deleteDownwardLinkModel = exports.createUpwardLinkModel = exports.createDownwardLinkModel = exports.updateConveyancing = exports.getConveyancingChain = exports.getConveyancing = exports.getConveyancingById = void 0;
const api_1 = require("./api");
const getConveyancingById = (args, context) => {
    const property = (0, api_1.callGetConveyancingByIdAPI)(args, context);
    return property;
};
exports.getConveyancingById = getConveyancingById;
const getConveyancing = (args, context) => {
    const companies = (0, api_1.callGetConveyancingAPI)(args, context);
    return companies;
};
exports.getConveyancing = getConveyancing;
const getConveyancingChain = (args, context) => {
    const companyChain = (0, api_1.callGetConveyancingChainAPI)(args, context);
    return companyChain;
};
exports.getConveyancingChain = getConveyancingChain;
const updateConveyancing = (args, context) => {
    const updateResult = (0, api_1.callUpdateConveyancingAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateConveyancing = updateConveyancing;
const createDownwardLinkModel = (args, context) => {
    const createResult = (0, api_1.callCreateDownwardLinkModelAPI)(args, context);
    return createResult;
};
exports.createDownwardLinkModel = createDownwardLinkModel;
const createUpwardLinkModel = (args, context) => {
    const createResult = (0, api_1.callCreateUpwardLinkModelAPI)(args, context);
    return createResult;
};
exports.createUpwardLinkModel = createUpwardLinkModel;
const deleteDownwardLinkModel = (args, context) => {
    const deleteResult = (0, api_1.callDeleteDownwardLinkModelAPI)(Object.assign({}, args), context);
    return deleteResult;
};
exports.deleteDownwardLinkModel = deleteDownwardLinkModel;
const deleteUpwardLinkModel = (args, context) => {
    const deleteResult = (0, api_1.callDeleteUpwardLinkModelAPI)(Object.assign({}, args), context);
    return deleteResult;
};
exports.deleteUpwardLinkModel = deleteUpwardLinkModel;
const propertyServices = {
    getConveyancingById: exports.getConveyancingById,
    getConveyancing: exports.getConveyancing,
    getConveyancingChain: exports.getConveyancingChain,
    updateConveyancing: exports.updateConveyancing,
    createDownwardLinkModel: exports.createDownwardLinkModel,
    createUpwardLinkModel: exports.createUpwardLinkModel,
    deleteDownwardLinkModel: exports.deleteDownwardLinkModel,
    deleteUpwardLinkModel: exports.deleteUpwardLinkModel,
};
exports.default = propertyServices;
//# sourceMappingURL=services.js.map