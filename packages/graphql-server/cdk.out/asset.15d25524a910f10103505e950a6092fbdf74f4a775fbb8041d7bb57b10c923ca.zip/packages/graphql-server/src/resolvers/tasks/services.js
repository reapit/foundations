"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateTask = exports.createTask = exports.getTasks = exports.getTaskById = void 0;
const api_1 = require("./api");
const getTaskById = (args, context) => {
    const property = (0, api_1.callGetTaskByIdAPI)(args, context);
    return property;
};
exports.getTaskById = getTaskById;
const getTasks = (args, context) => {
    const tasks = (0, api_1.callGetTasksAPI)(args, context);
    return tasks;
};
exports.getTasks = getTasks;
const createTask = (args, context) => {
    const createResult = (0, api_1.callCreateTaskAPI)(args, context);
    return createResult;
};
exports.createTask = createTask;
const updateTask = (args, context) => {
    const updateResult = (0, api_1.callUpdateTaskAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateTask = updateTask;
const propertyServices = {
    getTaskById: exports.getTaskById,
    getTasks: exports.getTasks,
    createTask: exports.createTask,
    updateTask: exports.updateTask,
};
exports.default = propertyServices;
//# sourceMappingURL=services.js.map