"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateTask = exports.mutationCreateTask = exports.queryGetTasks = exports.queryGetTaskById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetTaskById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getTaskById(args, context);
});
exports.queryGetTasks = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getTasks(args, context);
});
exports.mutationCreateTask = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createTask(args, context);
});
exports.mutationUpdateTask = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateTask(args, context);
});
exports.default = {
    Query: {
        GetTaskById: exports.queryGetTaskById,
        GetTasks: exports.queryGetTasks,
    },
    Mutation: {
        CreateTask: exports.mutationCreateTask,
        UpdateTask: exports.mutationUpdateTask,
    },
};
//# sourceMappingURL=resolvers.js.map