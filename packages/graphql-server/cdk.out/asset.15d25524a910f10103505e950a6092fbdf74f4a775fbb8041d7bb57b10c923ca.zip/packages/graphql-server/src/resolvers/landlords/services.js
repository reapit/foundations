"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteLandlordRelationship = exports.updateLandlord = exports.createLandlordRelationship = exports.createLandlord = exports.getLandlordRelationships = exports.getLandlordRelationshipById = exports.getLandlords = exports.getLandlordById = void 0;
const api_1 = require("./api");
const getLandlordById = (args, context) => {
    const landlord = (0, api_1.callGetLandlordByIdAPI)(args, context);
    return landlord;
};
exports.getLandlordById = getLandlordById;
const getLandlords = (args, context) => {
    const landlords = (0, api_1.callGetLandlordsAPI)(args, context);
    return landlords;
};
exports.getLandlords = getLandlords;
const getLandlordRelationshipById = (args, context) => {
    const landlordRelationship = (0, api_1.callGetLandlordRelationshipByIdAPI)(args, context);
    return landlordRelationship;
};
exports.getLandlordRelationshipById = getLandlordRelationshipById;
const getLandlordRelationships = (args, context) => {
    const landlordRelationships = (0, api_1.callGetLandlordRelationshipsAPI)(args, context);
    return landlordRelationships;
};
exports.getLandlordRelationships = getLandlordRelationships;
const createLandlord = (args, context) => {
    const createdLandlord = (0, api_1.callCreateLandlordAPI)(args, context);
    return createdLandlord;
};
exports.createLandlord = createLandlord;
const createLandlordRelationship = (args, context) => {
    const createdLandlordRelationship = (0, api_1.callCreateLandlordRelationshipAPI)(args, context);
    return createdLandlordRelationship;
};
exports.createLandlordRelationship = createLandlordRelationship;
const updateLandlord = (args, context) => {
    const updatedLandlord = (0, api_1.callUpdateLandlordAPI)(args, context);
    return updatedLandlord;
};
exports.updateLandlord = updateLandlord;
const deleteLandlordRelationship = (args, context) => {
    const isDeleted = (0, api_1.callDeleteLandlordRelationshipAPI)(args, context);
    return isDeleted;
};
exports.deleteLandlordRelationship = deleteLandlordRelationship;
const landlordServices = {
    getLandlordById: exports.getLandlordById,
    getLandlords: exports.getLandlords,
    getLandlordRelationships: exports.getLandlordRelationships,
    getLandlordRelationshipById: exports.getLandlordRelationshipById,
    createLandlord: exports.createLandlord,
    createLandlordRelationship: exports.createLandlordRelationship,
    deleteLandlordRelationship: exports.deleteLandlordRelationship,
    updateLandlord: exports.updateLandlord,
};
exports.default = landlordServices;
//# sourceMappingURL=services.js.map