"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateSource = exports.mutationCreateSource = exports.queryGetSources = exports.queryGetSourceById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetSourceById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getSourceById(args, context);
});
exports.queryGetSources = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getSources(args, context);
});
exports.mutationCreateSource = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createSource(args, context);
});
exports.mutationUpdateSource = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateSource(args, context);
});
exports.default = {
    Query: {
        GetSourceById: exports.queryGetSourceById,
        GetSources: exports.queryGetSources,
    },
    Mutation: {
        CreateSource: exports.mutationCreateSource,
        UpdateSource: exports.mutationUpdateSource,
    },
};
//# sourceMappingURL=resolvers.js.map