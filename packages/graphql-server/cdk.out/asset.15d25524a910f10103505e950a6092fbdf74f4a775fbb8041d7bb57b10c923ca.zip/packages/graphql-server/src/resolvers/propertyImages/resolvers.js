"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationDeletePropertyImage = exports.mutationUpdatePropertyImage = exports.mutationCreatePropertyImage = exports.queryGetPropertyImages = exports.queryGetPropertyImageById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetPropertyImageById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getPropertyImageById(args, context);
});
exports.queryGetPropertyImages = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getPropertyImages(args, context);
});
exports.mutationCreatePropertyImage = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createPropertyImage(args, context);
});
exports.mutationUpdatePropertyImage = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updatePropertyImage(args, context);
});
exports.mutationDeletePropertyImage = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.deletePropertyImage(args, context);
});
exports.default = {
    Query: {
        GetPropertyImageById: exports.queryGetPropertyImageById,
        GetPropertyImages: exports.queryGetPropertyImages,
    },
    Mutation: {
        CreatePropertyImage: exports.mutationCreatePropertyImage,
        UpdatePropertyImage: exports.mutationUpdatePropertyImage,
        DeletePropertyImage: exports.mutationDeletePropertyImage,
    },
};
//# sourceMappingURL=resolvers.js.map