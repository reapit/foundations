"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleError = void 0;
const logger_1 = __importDefault(require("../logger"));
const errors_1 = __importDefault(require("../errors"));
const serialize_error_1 = require("serialize-error");
const handleError = (_a) => __awaiter(void 0, [_a], void 0, function* ({ error, traceId, caller }) {
    var _b, _c, _d, _e, _f, _g, _h, _j;
    const reapitBackendError = (_b = error === null || error === void 0 ? void 0 : error.response) === null || _b === void 0 ? void 0 : _b.data;
    logger_1.default.error(caller, {
        traceId,
        // either a back-end error or system error (code crash)
        error: reapitBackendError ? reapitBackendError : (0, serialize_error_1.serializeError)(error),
        headers: (_c = error === null || error === void 0 ? void 0 : error.response) === null || _c === void 0 ? void 0 : _c.headers,
    });
    if (((_d = error === null || error === void 0 ? void 0 : error.response) === null || _d === void 0 ? void 0 : _d.status) === 400) {
        return errors_1.default.generateValidationError(traceId);
    }
    if (((_e = error === null || error === void 0 ? void 0 : error.response) === null || _e === void 0 ? void 0 : _e.status) === 401) {
        return errors_1.default.generateAuthenticationError(traceId);
    }
    if (((_f = error === null || error === void 0 ? void 0 : error.response) === null || _f === void 0 ? void 0 : _f.status) === 403) {
        return errors_1.default.generateForbiddenError(traceId);
    }
    if (((_g = error === null || error === void 0 ? void 0 : error.response) === null || _g === void 0 ? void 0 : _g.status) === 404) {
        return errors_1.default.generateNotFoundError(traceId);
    }
    if (((_h = error === null || error === void 0 ? void 0 : error.response) === null || _h === void 0 ? void 0 : _h.status) === 412) {
        return errors_1.default.generatePreconditionError(traceId);
    }
    if (((_j = error === null || error === void 0 ? void 0 : error.response) === null || _j === void 0 ? void 0 : _j.status) === 422) {
        return errors_1.default.generateUnprocessableError(traceId, reapitBackendError);
    }
    return errors_1.default.generateInternalServerError(traceId);
});
exports.handleError = handleError;
exports.default = exports.handleError;
//# sourceMappingURL=handle-error.js.map