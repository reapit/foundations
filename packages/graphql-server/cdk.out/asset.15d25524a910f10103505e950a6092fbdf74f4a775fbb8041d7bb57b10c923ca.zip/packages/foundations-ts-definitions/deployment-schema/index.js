"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PipelineRunnerType = exports.AppTypeEnum = exports.PackageManagerEnum = exports.pipelinePreprovisionedFlow = exports.pipelineProvisioning = exports.pipelineNotDeletable = exports.pipelineDeploymentDisabled = void 0;
exports.pipelineDeploymentDisabled = [
    'PROVISIONING',
    'PROVISION_REQUEST',
    'FAILED_TO_PROVISION',
    'PRE_PROVISIONED',
    'DELETING',
    'DELETED',
    'SCHEDULED_FOR_DELETION',
    'DELETION_REQUEST',
    'CREATED',
];
exports.pipelineNotDeletable = [
    'IN_PROGRESS',
    'DELETING',
    'PROVISION_REQUEST',
    'PROVISIONING',
    'QUEUED',
    'SCHEDULED_FOR_DELETION',
    'DELETION_REQUEST',
    'CREATED',
    'DELETED',
];
exports.pipelineProvisioning = ['PROVISIONING', 'PROVISION_REQUEST'];
exports.pipelinePreprovisionedFlow = ['PRE_PROVISIONED', 'PROVISIONING', 'PROVISION_REQUEST', 'FAILED_TO_PROVISION'];
var PackageManagerEnum;
(function (PackageManagerEnum) {
    PackageManagerEnum["NPM"] = "npm";
    PackageManagerEnum["YARN"] = "yarn";
    PackageManagerEnum["YARN_BERRY"] = "yarn-berry";
})(PackageManagerEnum || (exports.PackageManagerEnum = PackageManagerEnum = {}));
var AppTypeEnum;
(function (AppTypeEnum) {
    AppTypeEnum["NODE"] = "node";
    AppTypeEnum["REACT"] = "react";
})(AppTypeEnum || (exports.AppTypeEnum = AppTypeEnum = {}));
var PipelineRunnerType;
(function (PipelineRunnerType) {
    PipelineRunnerType["BUILD"] = "BUILD";
    PipelineRunnerType["RELEASE"] = "RELEASE";
    PipelineRunnerType["REPO"] = "REPO";
})(PipelineRunnerType || (exports.PipelineRunnerType = PipelineRunnerType = {}));
//# sourceMappingURL=index.js.map