"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.strToCamel = void 0;
const strToCamel = (str) => str
    .split(' ')
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
    .join('');
exports.strToCamel = strToCamel;
//# sourceMappingURL=casing-formatters.js.map