"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateContact = exports.createContact = exports.getContacts = exports.getContactById = void 0;
const api_1 = require("./api");
const getContactById = (args, context) => {
    const contact = (0, api_1.callGetContactByIdAPI)(args, context);
    return contact;
};
exports.getContactById = getContactById;
const getContacts = (args, context) => {
    const contacts = (0, api_1.callGetContactsAPI)(args, context);
    return contacts;
};
exports.getContacts = getContacts;
const createContact = (args, context) => {
    const createResult = (0, api_1.callCreateContactAPI)(args, context);
    return createResult;
};
exports.createContact = createContact;
const updateContact = (args, context) => {
    const updateResult = (0, api_1.callUpdateContactAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateContact = updateContact;
const contactServices = {
    getContactById: exports.getContactById,
    getContacts: exports.getContacts,
    createContact: exports.createContact,
    updateContact: exports.updateContact,
};
exports.default = contactServices;
//# sourceMappingURL=services.js.map