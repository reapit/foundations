"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateCompany = exports.mutationCreateCompany = exports.queryGetCompanyRoles = exports.queryGetCompanies = exports.queryGetCompanyById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetCompanyById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getCompanyById(args, context);
});
exports.queryGetCompanies = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getCompanies(args, context);
});
exports.queryGetCompanyRoles = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getCompanyRoles(args, context);
});
exports.mutationCreateCompany = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createCompany(args, context);
});
exports.mutationUpdateCompany = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateCompany(args, context);
});
exports.default = {
    Query: {
        GetCompanyById: exports.queryGetCompanyById,
        GetCompanies: exports.queryGetCompanies,
        GetCompanyRoles: exports.queryGetCompanyRoles,
    },
    Mutation: {
        CreateCompany: exports.mutationCreateCompany,
        UpdateCompany: exports.mutationUpdateCompany,
    },
};
//# sourceMappingURL=resolvers.js.map