"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateIdentityCheck = exports.mutationCreateIdentityCheck = exports.queryGetIdentityChecks = exports.queryGetIdentityCheckById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetIdentityCheckById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getIdentityCheckById(args, context);
});
exports.queryGetIdentityChecks = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getIdentityChecks(args, context);
});
exports.mutationCreateIdentityCheck = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createIdentityCheck(args, context);
});
exports.mutationUpdateIdentityCheck = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateIdentityCheck(args, context);
});
exports.default = {
    Query: {
        GetIdentityCheckById: exports.queryGetIdentityCheckById,
        GetIdentityChecks: exports.queryGetIdentityChecks,
    },
    Mutation: {
        CreateIdentityCheck: exports.mutationCreateIdentityCheck,
        UpdateIdentityCheck: exports.mutationUpdateIdentityCheck,
    },
};
//# sourceMappingURL=resolvers.js.map