"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createWistonLoggerErrorFn = exports.stringifyError = void 0;
const Sentry = __importStar(require("@sentry/node"));
const serialize_error_1 = require("serialize-error");
const utils_common_1 = require("@reapit/utils-common");
/**
 * convert any know error properties to object
 * stringtify using JSON.stringtify
 */
const stringifyError = (err) => JSON.stringify((0, serialize_error_1.serializeError)(err));
exports.stringifyError = stringifyError;
const createWistonLoggerErrorFn = (loggerError) => (caller, { error, traceId, headers }) => new Promise((resolve) => {
    loggerError(caller, { traceId, error: error });
    console.log({ traceId }, JSON.stringify(error, null, 2));
    if (process.env.NODE_ENV === 'development') {
        resolve(true);
    }
    Sentry.withScope((scope) => {
        scope.setExtra('Error', (0, utils_common_1.cleanObject)({
            caller,
            traceId,
            headers,
            error,
        }));
        Sentry.captureException(error);
        Sentry.flush(2000)
            .then(resolve)
            .catch((err) => {
            loggerError('logger.error', { error: err, traceId });
        });
    });
});
exports.createWistonLoggerErrorFn = createWistonLoggerErrorFn;
//# sourceMappingURL=sentry-logger.js.map