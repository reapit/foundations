"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasSpecialChars = exports.whiteListLocalhostAndIsValidUrl = exports.isValidHttpUrl = exports.isValidHttpsUrl = exports.isValidLimitToClientIds = exports.checkValidCustomScheme = exports.isValidUrlWithCustomScheme = exports.isImageType = void 0;
const isImageType = (type) => {
    const regex = /^image\//;
    return regex.test(type);
};
exports.isImageType = isImageType;
const isValidUrlWithCustomScheme = (urls) => {
    if (!urls) {
        return false;
    }
    // remove all white-space and filter all empty urls
    return urls
        .replace(/\s/g, '')
        .split(',')
        .filter((url) => url)
        .every((url) => (0, exports.checkValidCustomScheme)(url));
};
exports.isValidUrlWithCustomScheme = isValidUrlWithCustomScheme;
const checkValidCustomScheme = (url) => {
    const result = url.match(/([a-zA-Z-]{1,30}):\/\/([a-zA-Z\d-.:]{1,255})/);
    if (!result) {
        return false;
    }
    const [, protocol, link] = result;
    // allow http only for localhost
    if (protocol === 'http') {
        return link.indexOf('localhost') === 0;
    }
    return !!protocol && !!link;
};
exports.checkValidCustomScheme = checkValidCustomScheme;
const isValidLimitToClientIds = (clientIds) => {
    // Only allow strings with 15 characters seperated by a comma
    return clientIds
        .replace(/\s/g, '')
        .split(',')
        .every((clientId) => clientId.length >= 3 && clientId.length <= 15);
};
exports.isValidLimitToClientIds = isValidLimitToClientIds;
const isValidHttpsUrl = (url) => {
    return /^\s*(https:\/\/)([a-z\d-]{1,63}\.)*[a-z\d-]{1,255}(.[a-z]{2,6}|:[0-9]{2,6})\s*/.test(url);
};
exports.isValidHttpsUrl = isValidHttpsUrl;
const isValidHttpUrl = (url) => {
    return /^\s*(http:\/\/)([a-z\d-]{1,63}\.)*[a-z\d-]{1,255}(.[a-z]{2,6}|:[0-9]{2,6})\s*/.test(url);
};
exports.isValidHttpUrl = isValidHttpUrl;
const whiteListLocalhostAndIsValidUrl = (url) => {
    return (0, exports.isValidHttpsUrl)(url) || /http?:\/\/localhost/.test(url);
};
exports.whiteListLocalhostAndIsValidUrl = whiteListLocalhostAndIsValidUrl;
const hasSpecialChars = (value) => {
    if (!value)
        return false;
    if (/^[\w\-\s£$@%&*()?!%/=+'"~^,‘’.#;:]+$/.test(value) && /^((?!javascript).)*$/.test(value.toLowerCase())) {
        return false;
    }
    return true;
};
exports.hasSpecialChars = hasSpecialChars;
//# sourceMappingURL=index.js.map