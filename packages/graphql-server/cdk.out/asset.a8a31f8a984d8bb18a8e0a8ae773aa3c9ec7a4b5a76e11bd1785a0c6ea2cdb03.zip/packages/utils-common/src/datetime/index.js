"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.toLocalTime = exports.toUTCTime = exports.isSameDay = exports.getDate = exports.getTime = exports.DATE_TIME_FORMAT = void 0;
const dayjs_1 = __importDefault(require("dayjs"));
const utc_1 = __importDefault(require("dayjs/plugin/utc"));
dayjs_1.default.extend(utc_1.default);
exports.DATE_TIME_FORMAT = {
    RFC3339: 'YYYY-MM-DDTHH:mm:ssZ',
    DATE_FORMAT: 'DD MMM YYYY',
    DATE_TIME_FORMAT: 'DD MMM YYYY HH:mm',
    YYYY_MM_DD: 'YYYY-MM-DD',
    YYYY_MM: 'YYYY-MM',
    MMMM_YYYY: 'MMMM YYYY',
};
const getTime = (date, is24HourTime = false) => {
    return (0, dayjs_1.default)(date).format(is24HourTime ? 'HH:mm' : 'hh:mm A');
};
exports.getTime = getTime;
const getDate = (date, format = exports.DATE_TIME_FORMAT.DATE_FORMAT) => {
    return (0, dayjs_1.default)(date).format(format);
};
exports.getDate = getDate;
const isSameDay = (date) => {
    const toDate = (0, dayjs_1.default)();
    return (0, dayjs_1.default)(date).isSame(toDate, 'day');
};
exports.isSameDay = isSameDay;
const toUTCTime = (value, format = exports.DATE_TIME_FORMAT.RFC3339) => {
    if (!value) {
        return '';
    }
    const date = (0, dayjs_1.default)(value);
    return date.utc().format(format);
};
exports.toUTCTime = toUTCTime;
const toLocalTime = (value, format = exports.DATE_TIME_FORMAT.DATE_TIME_FORMAT) => {
    const date = (0, dayjs_1.default)(value);
    return date.local().format(format);
};
exports.toLocalTime = toLocalTime;
//# sourceMappingURL=index.js.map