"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pipelineViewable = exports.buildStatusToReadable = exports.runnerTypeToReadable = exports.buildStatusToIntent = void 0;
const buildStatusToIntent = (status) => {
    switch (status) {
        case 'PROVISIONING':
            return 'primary';
        case 'SUCCEEDED':
        case 'COMPLETED':
            return 'success';
        case 'IN_PROGRESS':
        case 'QUEUED':
            return 'neutral';
        case 'FAILED':
        case 'DELETING':
        case 'DELETED':
        case 'FAILED_TO_PROVISION':
        case 'SCHEDULED_FOR_DELETION':
            return 'danger';
        case 'PRE_PROVISIONED':
        case 'READY_FOR_DEPLOYMENT':
        default:
            return 'pending';
    }
};
exports.buildStatusToIntent = buildStatusToIntent;
const runnerTypeToReadable = (type) => {
    switch (type) {
        case 'BUILD':
            return 'Pulled from repo';
        case 'RELEASE':
            return 'Built from zip';
        case 'REPO':
            return 'Git pushed';
        default:
            return 'Unknown';
    }
};
exports.runnerTypeToReadable = runnerTypeToReadable;
const buildStatusToReadable = (status) => status
    .split('_')
    .map((str) => `${str.charAt(0).toUpperCase()}${str.slice(1).toLowerCase()}`)
    .join(' ');
exports.buildStatusToReadable = buildStatusToReadable;
const pipelineViewable = (status) => ![
    'DELETING',
    'SCHEDULED_FOR_DELETION',
    'DELETED',
    'PRE_PROVISIONED',
    'PROVISIONING',
    'PROVISION_REQUEST',
    'FAILED_TO_PROVISION',
    'READY_FOR_DEPLOYMENT',
].includes(status);
exports.pipelineViewable = pipelineViewable;
//# sourceMappingURL=index.js.map