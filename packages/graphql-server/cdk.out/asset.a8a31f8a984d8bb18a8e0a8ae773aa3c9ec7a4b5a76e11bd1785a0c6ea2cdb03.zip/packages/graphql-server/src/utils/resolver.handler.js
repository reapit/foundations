"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolverHandler = void 0;
const check_permission_1 = require("./check-permission");
const errors_1 = __importDefault(require("../errors"));
const resolverHandler = (func) => (_, args, context) => {
    const isPermit = (0, check_permission_1.checkPermission)(context);
    if (!isPermit) {
        return errors_1.default.generateAuthenticationError(context.traceId);
    }
    // TODO add harder try catch wrapper
    return func(_, args, context);
};
exports.resolverHandler = resolverHandler;
//# sourceMappingURL=resolver.handler.js.map