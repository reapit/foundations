"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateSource = exports.createSource = exports.getSources = exports.getSourceById = void 0;
const api_1 = require("./api");
const getSourceById = (args, context) => {
    const source = (0, api_1.callGetSourceByIdAPI)(args, context);
    return source;
};
exports.getSourceById = getSourceById;
const getSources = (args, context) => {
    const sources = (0, api_1.callGetSourcesAPI)(args, context);
    return sources;
};
exports.getSources = getSources;
const createSource = (args, context) => {
    const createResult = (0, api_1.callCreateSourceAPI)(args, context);
    return createResult;
};
exports.createSource = createSource;
const updateSource = (args, context) => {
    const updateResult = (0, api_1.callUpdateSourceAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateSource = updateSource;
const sourceServices = {
    getSourceById: exports.getSourceById,
    getSources: exports.getSources,
    createSource: exports.createSource,
    updateSource: exports.updateSource,
};
exports.default = sourceServices;
//# sourceMappingURL=services.js.map