"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createJournalEntry = exports.getJournalEntries = void 0;
const api_1 = require("./api");
const getJournalEntries = (args, context) => {
    const journalEntries = (0, api_1.callGetJournalEntriesAPI)(args, context);
    return journalEntries;
};
exports.getJournalEntries = getJournalEntries;
const createJournalEntry = (args, context) => {
    const createResult = (0, api_1.callCreateJournalEntryAPI)(args, context);
    return createResult;
};
exports.createJournalEntry = createJournalEntry;
const journalEntryServices = {
    getJournalEntries: exports.getJournalEntries,
    createJournalEntry: exports.createJournalEntry,
};
exports.default = journalEntryServices;
//# sourceMappingURL=services.js.map