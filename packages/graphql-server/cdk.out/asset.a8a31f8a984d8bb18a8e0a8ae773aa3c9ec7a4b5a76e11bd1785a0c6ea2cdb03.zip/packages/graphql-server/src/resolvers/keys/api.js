"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callUpdateKeyMovementAPI = exports.callCreateKeyMovementAPI = exports.callGetKeyMovementAPI = exports.callGetKeyMovementsAPI = exports.callCreateKeyAPI = exports.callGetKeyAPI = exports.callGetPropertyKeysAPI = void 0;
const errors_1 = __importDefault(require("../../errors"));
const api_1 = require("../../constants/api");
const axios_instances_1 = require("../../utils/axios-instances");
const handle_error_1 = require("../../utils/handle-error");
const get_id_from_create_headers_1 = require("../../utils/get-id-from-create-headers");
const callGetPropertyKeysAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { propertyId } = args;
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.properties}/${propertyId}/keys`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetPropertyKeysAPI' });
        throw handleErrorResult;
    }
});
exports.callGetPropertyKeysAPI = callGetPropertyKeysAPI;
const callGetKeyAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { propertyId, keyId } = args;
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.properties}/${propertyId}/keys/${keyId}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetKeyAPI' });
        throw handleErrorResult;
    }
});
exports.callGetKeyAPI = callGetKeyAPI;
const callCreateKeyAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    const { propertyId, key } = args;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().post(`${api_1.URLS.properties}/${propertyId}/keys`, key, {
            headers: {
                Authorization: context.authorization,
            },
        });
        const keyId = (0, get_id_from_create_headers_1.getIdFromCreateHeaders)({ headers: response.headers });
        if (keyId) {
            return (0, exports.callGetKeyAPI)({ keyId, propertyId }, context);
        }
        return null;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callCreateKeyAPI' });
        throw handleErrorResult;
    }
});
exports.callCreateKeyAPI = callCreateKeyAPI;
const callGetKeyMovementsAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { propertyId, keyId } = args;
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.properties}/${propertyId}/keys/${keyId}/movements`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetKeyMovementsAPI' });
        throw handleErrorResult;
    }
});
exports.callGetKeyMovementsAPI = callGetKeyMovementsAPI;
const callGetKeyMovementAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { propertyId, keyId, movementId } = args;
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.properties}/${propertyId}/keys/${keyId}/movements/${movementId}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetKeyMovementsAPI' });
        throw handleErrorResult;
    }
});
exports.callGetKeyMovementAPI = callGetKeyMovementAPI;
const callCreateKeyMovementAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { propertyId, keyId, movement } = args;
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().post(`${api_1.URLS.properties}/${propertyId}/keys/${keyId}/movements`, movement, {
            headers: {
                Authorization: context.authorization,
            },
        });
        const movementId = (0, get_id_from_create_headers_1.getIdFromCreateHeaders)({ headers: response.headers });
        if (movementId) {
            return (0, exports.callGetKeyMovementAPI)({ keyId, propertyId, movementId }, context);
        }
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callCreateKeyMovementAPI' });
        throw handleErrorResult;
    }
});
exports.callCreateKeyMovementAPI = callCreateKeyMovementAPI;
const callUpdateKeyMovementAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { propertyId, keyId, movementId } = args, rest = __rest(args, ["propertyId", "keyId", "movementId"]);
        const updateResponse = yield (0, axios_instances_1.createPlatformAxiosInstance)().put(`${api_1.URLS.properties}/${propertyId}/keys/${keyId}/movements/${movementId}`, rest, {
            headers: {
                Authorization: context.authorization,
            },
        });
        if (updateResponse.status === 204) {
            return (0, exports.callGetKeyMovementAPI)(args, context);
        }
        throw errors_1.default.generateUserInputError(traceId);
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callUpdateKeyMovementAPI' });
        throw handleErrorResult;
    }
});
exports.callUpdateKeyMovementAPI = callUpdateKeyMovementAPI;
//# sourceMappingURL=api.js.map