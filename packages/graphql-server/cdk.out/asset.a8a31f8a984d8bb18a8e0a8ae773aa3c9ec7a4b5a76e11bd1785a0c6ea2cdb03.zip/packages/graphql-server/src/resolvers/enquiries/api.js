"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callCreateEnquiryAPI = exports.callGetEnquiriesAPI = exports.callGetEnquiryByIdAPI = void 0;
const query_string_1 = __importDefault(require("query-string"));
const api_1 = require("../../constants/api");
const axios_instances_1 = require("../../utils/axios-instances");
const handle_error_1 = require("../../utils/handle-error");
const get_id_from_create_headers_1 = require("../../utils/get-id-from-create-headers");
const callGetEnquiryByIdAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.enquiries}/${args.id}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetEnquiryByIdAPI' });
        return handleErrorResult;
    }
});
exports.callGetEnquiryByIdAPI = callGetEnquiryByIdAPI;
const callGetEnquiriesAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const params = query_string_1.default.stringify(args);
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.enquiries}?${params}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetEnquiriesAPI' });
        return handleErrorResult;
    }
});
exports.callGetEnquiriesAPI = callGetEnquiriesAPI;
const callCreateEnquiryAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().post(api_1.URLS.enquiries, args, {
            headers: {
                Authorization: context.authorization,
            },
        });
        const id = (0, get_id_from_create_headers_1.getIdFromCreateHeaders)({ headers: response.headers });
        if (id) {
            return (0, exports.callGetEnquiryByIdAPI)({ id: parseInt(id) }, context);
        }
        return null;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callCreateEnquiryAPI' });
        return handleErrorResult;
    }
});
exports.callCreateEnquiryAPI = callCreateEnquiryAPI;
//# sourceMappingURL=api.js.map