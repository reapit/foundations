"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolvers = void 0;
const lodash_merge_1 = __importDefault(require("lodash.merge"));
const graphql_type_json_1 = __importDefault(require("graphql-type-json"));
const resolvers_1 = __importDefault(require("./contacts/resolvers"));
const resolvers_2 = __importDefault(require("./areas/resolvers"));
const resolvers_3 = __importDefault(require("./offices/resolvers"));
const resolvers_4 = __importDefault(require("./appointments/resolvers"));
const resolvers_5 = __importDefault(require("./negotiators/resolvers"));
const resolvers_6 = __importDefault(require("./properties/resolvers"));
const resolvers_7 = __importDefault(require("./propertyImages/resolvers"));
const resolver_1 = __importDefault(require("./configurations/resolver"));
const resolvers_8 = __importDefault(require("./identity-checks/resolvers"));
const resolvers_9 = __importDefault(require("./ping/resolvers"));
const resolvers_10 = __importDefault(require("./tenancies/resolvers"));
const resolvers_11 = __importDefault(require("./applicants/resolvers"));
const resolvers_12 = __importDefault(require("./offers/resolvers"));
const resolvers_13 = __importDefault(require("./vendors/resolvers"));
const resolvers_14 = __importDefault(require("./companies/resolvers"));
const resolvers_15 = __importDefault(require("./conveyancing/resolvers"));
const resolvers_16 = __importDefault(require("./landlords/resolvers"));
const resolvers_17 = __importDefault(require("./tasks/resolvers"));
const resolvers_18 = __importDefault(require("./departments/resolvers"));
const resolvers_19 = __importDefault(require("./sources/resolvers"));
const resolvers_20 = __importDefault(require("./journal-entries/resolvers"));
const resolvers_21 = __importDefault(require("./enquiries/resolvers"));
const resolvers_22 = __importDefault(require("./works-orders/resolvers"));
const resolvers_23 = __importDefault(require("./documents/resolvers"));
const resolvers_24 = __importDefault(require("./keys/resolvers"));
exports.resolvers = (0, lodash_merge_1.default)({
    JSON: graphql_type_json_1.default,
}, resolvers_11.default, resolvers_4.default, resolvers_2.default, resolver_1.default, resolvers_1.default, resolvers_8.default, resolvers_5.default, resolvers_3.default, resolvers_9.default, resolvers_6.default, resolvers_7.default, resolvers_17.default, resolvers_10.default, resolvers_12.default, resolvers_13.default, resolvers_14.default, resolvers_15.default, resolvers_16.default, resolvers_18.default, resolvers_19.default, resolvers_20.default, resolvers_21.default, resolvers_22.default, resolvers_23.default, resolvers_24.default);
exports.default = exports.resolvers;
//# sourceMappingURL=index.js.map