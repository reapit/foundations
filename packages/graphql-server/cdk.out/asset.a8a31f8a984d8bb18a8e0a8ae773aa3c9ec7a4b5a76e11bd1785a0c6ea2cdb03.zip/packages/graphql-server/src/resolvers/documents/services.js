"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteDocument = exports.updateDocument = exports.createDocument = exports.getDocuments = exports.getDocumentById = void 0;
const api_1 = require("./api");
const getDocumentById = (args, context) => {
    const document = (0, api_1.callGetDocumentByIdAPI)(args, context);
    return document;
};
exports.getDocumentById = getDocumentById;
const getDocuments = (args, context) => {
    const documents = (0, api_1.callGetDocumentsAPI)(args, context);
    return documents;
};
exports.getDocuments = getDocuments;
const createDocument = (args, context) => {
    const createResult = (0, api_1.callCreateDocumentAPI)(args, context);
    return createResult;
};
exports.createDocument = createDocument;
const updateDocument = (args, context) => {
    const updateResult = (0, api_1.callUpdateDocumentAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateDocument = updateDocument;
const deleteDocument = (args, context) => {
    const deleteResult = (0, api_1.callDeleteDocumentAPI)(args, context);
    return deleteResult;
};
exports.deleteDocument = deleteDocument;
const documentServices = {
    getDocumentById: exports.getDocumentById,
    getDocuments: exports.getDocuments,
    createDocument: exports.createDocument,
    updateDocument: exports.updateDocument,
    deleteDocument: exports.deleteDocument,
};
exports.default = documentServices;
//# sourceMappingURL=services.js.map