"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDepartments = exports.getDepartmentById = void 0;
const api_1 = require("./api");
const getDepartmentById = (args, context) => {
    const department = (0, api_1.callGetDepartmentByIdAPI)(args, context);
    return department;
};
exports.getDepartmentById = getDepartmentById;
const getDepartments = (args, context) => {
    const departments = (0, api_1.callGetDepartmentsAPI)(args, context);
    return departments;
};
exports.getDepartments = getDepartments;
const departmentServices = {
    getDepartmentById: exports.getDepartmentById,
    getDepartments: exports.getDepartments,
};
exports.default = departmentServices;
//# sourceMappingURL=services.js.map