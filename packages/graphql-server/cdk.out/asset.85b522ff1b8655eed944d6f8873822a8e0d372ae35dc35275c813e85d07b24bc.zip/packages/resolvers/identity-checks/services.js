"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateIdentityCheck = exports.createIdentityCheck = exports.getIdentityChecks = exports.getIdentityCheckById = void 0;
const api_1 = require("./api");
const getIdentityCheckById = (args, context) => {
    const identityCheck = (0, api_1.callGetIdentityCheckByIdAPI)(args, context);
    return identityCheck;
};
exports.getIdentityCheckById = getIdentityCheckById;
const getIdentityChecks = (args, context) => {
    const identityChecks = (0, api_1.callGetIdentityChecksAPI)(args, context);
    return identityChecks;
};
exports.getIdentityChecks = getIdentityChecks;
const createIdentityCheck = (args, context) => {
    const createResult = (0, api_1.callCreateIdentityCheckAPI)(args, context);
    return createResult;
};
exports.createIdentityCheck = createIdentityCheck;
const updateIdentityCheck = (args, context) => {
    const updateResult = (0, api_1.callUpdateIdentityCheckAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateIdentityCheck = updateIdentityCheck;
const identityCheckServices = {
    getIdentityCheckById: exports.getIdentityCheckById,
    getIdentityChecks: exports.getIdentityChecks,
    createIdentityCheck: exports.createIdentityCheck,
    updateIdentityCheck: exports.updateIdentityCheck,
};
exports.default = identityCheckServices;
//# sourceMappingURL=services.js.map