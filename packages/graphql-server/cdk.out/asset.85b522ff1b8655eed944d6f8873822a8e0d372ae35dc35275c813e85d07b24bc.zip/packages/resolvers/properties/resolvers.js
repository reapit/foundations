"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateProperty = exports.mutationCreateProperty = exports.queryGetProperties = exports.queryGetPropertyById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetPropertyById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getPropertyById(args, context);
});
exports.queryGetProperties = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getProperties(args, context);
});
exports.mutationCreateProperty = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createProperty(args, context);
});
exports.mutationUpdateProperty = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateProperty(args, context);
});
exports.default = {
    Query: {
        GetPropertyById: exports.queryGetPropertyById,
        GetProperties: exports.queryGetProperties,
    },
    Mutation: {
        CreateProperty: exports.mutationCreateProperty,
        UpdateProperty: exports.mutationUpdateProperty,
    },
};
//# sourceMappingURL=resolvers.js.map