"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationDeleteApplicantRelationship = exports.mutationCreateApplicantRelationship = exports.queryGetApplicantRelationships = exports.queryGetApplicantRelationshipById = exports.mutationUpdateApplicant = exports.mutationCreateApplicant = exports.queryGetApplicants = exports.queryGetApplicantById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetApplicantById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getApplicantById(args, context);
});
exports.queryGetApplicants = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getApplicants(args, context);
});
exports.mutationCreateApplicant = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createApplicant(args, context);
});
exports.mutationUpdateApplicant = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateApplicant(args, context);
});
exports.queryGetApplicantRelationshipById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getApplicantRelationshipById(args, context);
});
exports.queryGetApplicantRelationships = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getApplicantRelationships(args, context);
});
exports.mutationCreateApplicantRelationship = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createApplicantRelationship(args, context);
});
exports.mutationDeleteApplicantRelationship = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.deleteApplicantRelationship(args, context);
});
exports.default = {
    Query: {
        GetApplicantById: exports.queryGetApplicantById,
        GetApplicants: exports.queryGetApplicants,
        GetApplicantRelationshipById: exports.queryGetApplicantRelationshipById,
        GetApplicantRelationships: exports.queryGetApplicantRelationships,
    },
    Mutation: {
        CreateApplicant: exports.mutationCreateApplicant,
        UpdateApplicant: exports.mutationUpdateApplicant,
        CreateApplicantRelationship: exports.mutationCreateApplicantRelationship,
        DeleteApplicantRelationship: exports.mutationDeleteApplicantRelationship,
    },
};
//# sourceMappingURL=resolvers.js.map