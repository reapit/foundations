"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationDeleteDocument = exports.mutationUpdateDocument = exports.mutationCreateDocument = exports.queryGetDocuments = exports.queryGetDocumentById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetDocumentById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getDocumentById(args, context);
});
exports.queryGetDocuments = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getDocuments(args, context);
});
exports.mutationCreateDocument = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createDocument(args, context);
});
exports.mutationUpdateDocument = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateDocument(args, context);
});
exports.mutationDeleteDocument = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.deleteDocument(args, context);
});
exports.default = {
    Query: {
        GetDocumentById: exports.queryGetDocumentById,
        GetDocuments: exports.queryGetDocuments,
    },
    Mutation: {
        CreateDocument: exports.mutationCreateDocument,
        UpdateDocument: exports.mutationUpdateDocument,
        DeleteDocument: exports.mutationDeleteDocument,
    },
};
//# sourceMappingURL=resolvers.js.map