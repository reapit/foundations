"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryGetConfigurationsByTypeAndId = exports.queryGetConfigurationsByType = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetConfigurationsByType = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getConfigurationsByType(args, context);
});
exports.queryGetConfigurationsByTypeAndId = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getConfigurationByTypeAndId(args, context);
});
exports.default = {
    Query: {
        GetConfigurationsByType: exports.queryGetConfigurationsByType,
        GetConfigurationByTypeAndId: exports.queryGetConfigurationsByTypeAndId,
    },
};
//# sourceMappingURL=resolver.js.map