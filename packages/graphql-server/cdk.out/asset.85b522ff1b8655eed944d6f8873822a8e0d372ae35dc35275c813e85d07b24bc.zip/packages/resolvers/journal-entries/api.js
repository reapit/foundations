"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callCreateJournalEntryAPI = exports.callGetJournalEntriesAPI = void 0;
const query_string_1 = __importDefault(require("query-string"));
const api_1 = require("../../constants/api");
const axios_instances_1 = require("../../utils/axios-instances");
const handle_error_1 = require("../../utils/handle-error");
const callGetJournalEntriesAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const params = query_string_1.default.stringify(args);
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.journalEntries}?${params}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetJournalEntriesAPI' });
        return handleErrorResult;
    }
});
exports.callGetJournalEntriesAPI = callGetJournalEntriesAPI;
const callCreateJournalEntryAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().post(api_1.URLS.journalEntries, args, {
            headers: {
                Authorization: context.authorization,
            },
        });
        if (response.status === 204) {
            return true;
        }
        return false;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callCreateJournalEntryAPI' });
        return handleErrorResult;
    }
});
exports.callCreateJournalEntryAPI = callCreateJournalEntryAPI;
//# sourceMappingURL=api.js.map