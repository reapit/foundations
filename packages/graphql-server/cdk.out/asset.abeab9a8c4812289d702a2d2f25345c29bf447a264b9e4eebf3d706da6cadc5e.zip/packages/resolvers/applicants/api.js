"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callDeleteApplicantRelationshipAPI = exports.callCreateApplicantRelationshipAPI = exports.callGetApplicantRelationshipsAPI = exports.callGetApplicantRelationshipByIdAPI = exports.callUpdateApplicantAPI = exports.callCreateApplicantAPI = exports.callGetApplicantsAPI = exports.callGetApplicantByIdAPI = void 0;
const query_string_1 = __importDefault(require("query-string"));
const errors_1 = __importDefault(require("../../errors"));
const axios_instances_1 = require("../../utils/axios-instances");
const api_1 = require("../../constants/api");
const handle_error_1 = require("../../utils/handle-error");
const get_id_from_create_headers_1 = require("../../utils/get-id-from-create-headers");
const callGetApplicantByIdAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { id } = args, rest = __rest(args, ["id"]);
        const params = query_string_1.default.stringify(rest);
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.applicants}/${id}?${params}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetApplicantByIdAPI' });
        return handleErrorResult;
    }
});
exports.callGetApplicantByIdAPI = callGetApplicantByIdAPI;
const callGetApplicantsAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const params = query_string_1.default.stringify(args);
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.applicants}?${params}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetApplicantsAPI' });
        return handleErrorResult;
    }
});
exports.callGetApplicantsAPI = callGetApplicantsAPI;
const callCreateApplicantAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().post(api_1.URLS.applicants, args, {
            headers: {
                Authorization: context.authorization,
            },
        });
        const id = (0, get_id_from_create_headers_1.getIdFromCreateHeaders)({ headers: response.headers });
        if (id) {
            return (0, exports.callGetApplicantByIdAPI)({ id }, context);
        }
        return null;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callCreateApplicantAPI' });
        return handleErrorResult;
    }
});
exports.callCreateApplicantAPI = callCreateApplicantAPI;
const callUpdateApplicantAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const { _eTag } = args, payload = __rest(args, ["_eTag"]);
        const updateResponse = yield (0, axios_instances_1.createPlatformAxiosInstance)().patch(`${api_1.URLS.applicants}/${args.id}`, payload, {
            headers: {
                Authorization: context.authorization,
                'If-Match': _eTag,
            },
        });
        if (updateResponse) {
            return (0, exports.callGetApplicantByIdAPI)({ id: args.id }, context);
        }
        return errors_1.default.generateUserInputError(traceId);
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callUpdateApplicantAPI' });
        return handleErrorResult;
    }
});
exports.callUpdateApplicantAPI = callUpdateApplicantAPI;
const callGetApplicantRelationshipByIdAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.applicants}/${args.id}/relationships/${args.relationshipId}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetApplicantRelationshipByIdAPI' });
        return handleErrorResult;
    }
});
exports.callGetApplicantRelationshipByIdAPI = callGetApplicantRelationshipByIdAPI;
const callGetApplicantRelationshipsAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const params = query_string_1.default.stringify(args);
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().get(`${api_1.URLS.applicants}/${args.id}/relationships?${params}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        return response === null || response === void 0 ? void 0 : response.data;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callGetApplicantRelationshipsAPI' });
        return handleErrorResult;
    }
});
exports.callGetApplicantRelationshipsAPI = callGetApplicantRelationshipsAPI;
const callCreateApplicantRelationshipAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().post(`${api_1.URLS.applicants}/${args.id}/relationships`, args, {
            headers: {
                Authorization: context.authorization,
            },
        });
        const relationshipId = (0, get_id_from_create_headers_1.getIdFromCreateHeaders)({ headers: response.headers });
        if (relationshipId) {
            return (0, exports.callGetApplicantRelationshipByIdAPI)({ id: args.id, relationshipId }, context);
        }
        return null;
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callCreateApplicantRelationshipsAPI' });
        return handleErrorResult;
    }
});
exports.callCreateApplicantRelationshipAPI = callCreateApplicantRelationshipAPI;
const callDeleteApplicantRelationshipAPI = (args, context) => __awaiter(void 0, void 0, void 0, function* () {
    const traceId = context.traceId;
    try {
        const response = yield (0, axios_instances_1.createPlatformAxiosInstance)().delete(`${api_1.URLS.applicants}/${args.id}/relationships/${args.relationshipId}`, {
            headers: {
                Authorization: context.authorization,
            },
        });
        if (response.status === 204) {
            return args.relationshipId;
        }
    }
    catch (error) {
        const handleErrorResult = yield (0, handle_error_1.handleError)({ error, traceId, caller: 'callDeleteApplicantRelationshipsByIdAPI' });
        return handleErrorResult;
    }
});
exports.callDeleteApplicantRelationshipAPI = callDeleteApplicantRelationshipAPI;
//# sourceMappingURL=api.js.map