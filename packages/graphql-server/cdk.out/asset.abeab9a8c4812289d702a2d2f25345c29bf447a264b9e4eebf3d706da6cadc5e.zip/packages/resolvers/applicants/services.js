"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteApplicantRelationship = exports.createApplicantRelationship = exports.getApplicantRelationships = exports.getApplicantRelationshipById = exports.updateApplicant = exports.createApplicant = exports.getApplicants = exports.getApplicantById = void 0;
const api_1 = require("./api");
const getApplicantById = (args, context) => {
    const applicant = (0, api_1.callGetApplicantByIdAPI)(args, context);
    return applicant;
};
exports.getApplicantById = getApplicantById;
const getApplicants = (args, context) => {
    const applicants = (0, api_1.callGetApplicantsAPI)(args, context);
    return applicants;
};
exports.getApplicants = getApplicants;
const createApplicant = (args, context) => {
    const createResult = (0, api_1.callCreateApplicantAPI)(args, context);
    return createResult;
};
exports.createApplicant = createApplicant;
const updateApplicant = (args, context) => {
    const updateResult = (0, api_1.callUpdateApplicantAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateApplicant = updateApplicant;
const getApplicantRelationshipById = (args, context) => {
    const applicant = (0, api_1.callGetApplicantRelationshipByIdAPI)(args, context);
    return applicant;
};
exports.getApplicantRelationshipById = getApplicantRelationshipById;
const getApplicantRelationships = (args, context) => {
    const applicants = (0, api_1.callGetApplicantRelationshipsAPI)(args, context);
    return applicants;
};
exports.getApplicantRelationships = getApplicantRelationships;
const createApplicantRelationship = (args, context) => {
    const createResult = (0, api_1.callCreateApplicantRelationshipAPI)(args, context);
    return createResult;
};
exports.createApplicantRelationship = createApplicantRelationship;
const deleteApplicantRelationship = (args, context) => {
    const deleteResult = (0, api_1.callDeleteApplicantRelationshipAPI)(args, context);
    return deleteResult;
};
exports.deleteApplicantRelationship = deleteApplicantRelationship;
const applicantServices = {
    getApplicantById: exports.getApplicantById,
    getApplicants: exports.getApplicants,
    createApplicant: exports.createApplicant,
    updateApplicant: exports.updateApplicant,
    getApplicantRelationshipById: exports.getApplicantRelationshipById,
    getApplicantRelationships: exports.getApplicantRelationships,
    createApplicantRelationship: exports.createApplicantRelationship,
    deleteApplicantRelationship: exports.deleteApplicantRelationship,
};
exports.default = applicantServices;
//# sourceMappingURL=services.js.map