"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfigurationsByType = exports.getConfigurationByTypeAndId = void 0;
const api_1 = require("./api");
const getConfigurationByTypeAndId = (args, context) => {
    const configurations = (0, api_1.callGetConfigurationsByTypeAndIdApi)(args, context);
    return configurations;
};
exports.getConfigurationByTypeAndId = getConfigurationByTypeAndId;
const getConfigurationsByType = (args, context) => {
    const configuration = (0, api_1.callGetConfigurationsByTypeApi)(args, context);
    return configuration;
};
exports.getConfigurationsByType = getConfigurationsByType;
const propertyTypeService = {
    getConfigurationByTypeAndId: exports.getConfigurationByTypeAndId,
    getConfigurationsByType: exports.getConfigurationsByType,
};
exports.default = propertyTypeService;
//# sourceMappingURL=services.js.map