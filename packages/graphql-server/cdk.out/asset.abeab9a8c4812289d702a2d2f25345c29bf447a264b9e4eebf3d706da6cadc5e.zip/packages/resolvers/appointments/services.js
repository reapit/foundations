"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppointment = exports.createAppointment = exports.getAppointments = exports.getAppointmentById = void 0;
const api_1 = require("./api");
const getAppointmentById = (args, context) => {
    const appointment = (0, api_1.callGetAppointmentByIdAPI)(args, context);
    return appointment;
};
exports.getAppointmentById = getAppointmentById;
const getAppointments = (args, context) => {
    const appointments = (0, api_1.callGetAppointmentsAPI)(args, context);
    return appointments;
};
exports.getAppointments = getAppointments;
const createAppointment = (args, context) => {
    const createResult = (0, api_1.callCreateAppointmentAPI)(args, context);
    return createResult;
};
exports.createAppointment = createAppointment;
const updateAppointment = (args, context) => {
    const updateResult = (0, api_1.callUpdateAppointmentAPI)(Object.assign({}, args), context);
    return updateResult;
};
exports.updateAppointment = updateAppointment;
const appointmentServices = {
    getAppointmentById: exports.getAppointmentById,
    getAppointments: exports.getAppointments,
    createAppointment: exports.createAppointment,
    updateAppointment: exports.updateAppointment,
};
exports.default = appointmentServices;
//# sourceMappingURL=services.js.map