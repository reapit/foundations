"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pingResolver = void 0;
const pingResolver = () => {
    return 'Services is running';
};
exports.pingResolver = pingResolver;
exports.default = {
    Query: {
        Ping: exports.pingResolver,
    },
};
//# sourceMappingURL=resolvers.js.map