"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getIdFromCreateHeaders = void 0;
const getIdFromCreateHeaders = ({ headers }) => {
    var _a;
    const locationArray = ((_a = headers === null || headers === void 0 ? void 0 : headers.location) === null || _a === void 0 ? void 0 : _a.split('/')) || [];
    const LAST_INDEX = locationArray.length - 1;
    return locationArray[LAST_INDEX] ? locationArray[LAST_INDEX] : undefined;
};
exports.getIdFromCreateHeaders = getIdFromCreateHeaders;
//# sourceMappingURL=get-id-from-create-headers.js.map