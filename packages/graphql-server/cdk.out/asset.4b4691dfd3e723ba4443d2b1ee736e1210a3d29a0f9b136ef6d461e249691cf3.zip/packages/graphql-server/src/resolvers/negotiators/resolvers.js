"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mutationUpdateNegotiator = exports.mutationCreateNegotiator = exports.queryGetNegotiators = exports.queryGetNegotiatorById = void 0;
const services_1 = __importDefault(require("./services"));
const utils_1 = require("../../utils");
exports.queryGetNegotiatorById = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getNegotiatorById(args, context);
});
exports.queryGetNegotiators = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.getNegotiators(args, context);
});
exports.mutationCreateNegotiator = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.createNegotiator(args, context);
});
exports.mutationUpdateNegotiator = (0, utils_1.resolverHandler)((_, args, context) => {
    return services_1.default.updateNegotiator(args, context);
});
exports.default = {
    Query: {
        GetNegotiatorById: exports.queryGetNegotiatorById,
        GetNegotiators: exports.queryGetNegotiators,
    },
    Mutation: {
        CreateNegotiator: exports.mutationCreateNegotiator,
        UpdateNegotiator: exports.mutationUpdateNegotiator,
    },
};
//# sourceMappingURL=resolvers.js.map