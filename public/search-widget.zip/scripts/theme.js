window.addEventListener("load", function() {
  if (window.initReaptSearchWidget) {
    window.initReaptSearchWidget({
      API_KEY: "abc",
      theme: {
        colors: {}
      }
    });
  }
});